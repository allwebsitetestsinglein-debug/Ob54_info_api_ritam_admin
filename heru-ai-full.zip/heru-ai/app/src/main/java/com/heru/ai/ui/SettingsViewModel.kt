package com.heru.ai.ui

import android.app.Application
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.heru.ai.HeruApplication
import com.heru.ai.ai.GeminiException
import com.heru.ai.ai.Turn
import com.heru.ai.data.HeruSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiMessage(val text: String, val ok: Boolean)

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val h = app as HeruApplication

    val settings: StateFlow<HeruSettings> =
        h.settingsRepo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, HeruSettings())

    fun <T> put(key: Preferences.Key<T>, value: T) {
        viewModelScope.launch { h.settingsRepo.put(key, value) }
    }

    // ----- API key -----
    private val _hasKey = MutableStateFlow(h.keyStore.hasKey())
    val hasKey = _hasKey.asStateFlow()

    fun saveKey(key: String) {
        val k = key.trim()
        if (k.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            h.keyStore.save(k)
            _hasKey.value = true
            _testResult.value = UiMessage("API key save ho gayi (Android Keystore se encrypted).", true)
        }
    }

    fun removeKey() {
        h.keyStore.clear()
        _hasKey.value = false
        _testResult.value = UiMessage("API key hata di.", true)
    }

    private suspend fun resolveKey(typed: String): String? =
        typed.trim().ifBlank { withContext(Dispatchers.IO) { h.keyStore.load() } }

    // ----- test + models -----
    private val _testResult = MutableStateFlow<UiMessage?>(null)
    val testResult = _testResult.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()
    private val _models = MutableStateFlow<List<String>>(emptyList())
    val models = _models.asStateFlow()

    fun testConnection(typedKey: String) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val key = resolveKey(typedKey)
                if (key.isNullOrBlank()) {
                    _testResult.value = UiMessage("Pehle API key daal ya save kar.", false)
                    return@launch
                }
                val s = settings.value
                h.gemini.generate(key, s.model, "You are a connection test.", listOf(Turn("user", "Say OK.")), 0f, 256)
                _testResult.value = UiMessage("Connection OK (model: ${s.model}).", true)
            } catch (e: GeminiException) {
                _testResult.value = UiMessage(e.message ?: "Connection fail.", false)
            } catch (e: Exception) {
                _testResult.value = UiMessage("Connection fail: ${e.javaClass.simpleName}", false)
            } finally {
                _busy.value = false
            }
        }
    }

    fun fetchModels(typedKey: String) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val key = resolveKey(typedKey)
                if (key.isNullOrBlank()) {
                    _testResult.value = UiMessage("Pehle API key daal ya save kar.", false)
                    return@launch
                }
                val list = h.gemini.listModels(key)
                _models.value = list
                _testResult.value = UiMessage("${list.size} Gemini models mile. Neeche se chun.", true)
            } catch (e: GeminiException) {
                _testResult.value = UiMessage(e.message ?: "Models load nahi hue.", false)
            } catch (e: Exception) {
                _testResult.value = UiMessage("Models load nahi hue: ${e.javaClass.simpleName}", false)
            } finally {
                _busy.value = false
            }
        }
    }

    // ----- voice -----
    private val _voices = MutableStateFlow<List<String>>(emptyList())
    val voices = _voices.asStateFlow()

    fun loadVoices() {
        val tag = settings.value.language.ttsTag
        h.voice.loadVoices(tag) { _voices.value = it }
    }

    fun testVoice() {
        val s = settings.value
        h.voice.speak(
            if (s.language.name == "ENGLISH") "Hello! This is how I sound." else "Ekdam badhiya bhai! Meri awaaz aisi hai.",
            s.language.ttsTag, s.ttsRate, s.ttsPitch, s.ttsVoice
        )
    }

    // ----- privacy -----
    fun clearChat() {
        viewModelScope.launch(Dispatchers.IO) {
            h.store.clearChat()
            h.chatCleared.tryEmit(Unit)
        }
    }

    fun clearMemories() {
        viewModelScope.launch(Dispatchers.IO) { h.store.clearMemories() }
    }

    fun resetSettings() {
        viewModelScope.launch { h.settingsRepo.resetAll() }
    }

    /** Turning history off also deletes what is already stored. */
    fun setSaveHistory(on: Boolean) {
        put(com.heru.ai.data.Keys.HISTORY, on)
        if (!on) viewModelScope.launch(Dispatchers.IO) { h.store.clearChat() }
    }
}
