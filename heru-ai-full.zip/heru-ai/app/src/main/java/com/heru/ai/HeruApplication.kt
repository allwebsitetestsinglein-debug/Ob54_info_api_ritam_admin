package com.heru.ai

import android.app.Application
import com.heru.ai.actions.ActionExecutor
import com.heru.ai.actions.ActionResult
import com.heru.ai.actions.CommandRouter
import com.heru.ai.ai.GeminiClient
import com.heru.ai.data.AppRepository
import com.heru.ai.data.HeruAction
import com.heru.ai.data.HeruLanguage
import com.heru.ai.data.LocalStore
import com.heru.ai.data.SecureKeyStore
import com.heru.ai.data.SettingsRepository
import com.heru.ai.voice.VoiceController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch

/** Tiny service locator: one instance of each service for the whole app. */
class HeruApplication : Application() {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val settingsRepo by lazy { SettingsRepository(this) }
    val keyStore by lazy { SecureKeyStore(this) }
    val store by lazy { LocalStore(this) }
    val appRepo by lazy { AppRepository(this) }
    val gemini by lazy { GeminiClient() }
    val executor by lazy { ActionExecutor(this) }
    val router by lazy { CommandRouter(appRepo, store) }
    val voice by lazy { VoiceController(this) }

    /** Emitted when chat history is cleared from Settings so the home screen resets too. */
    val chatCleared = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    /** Runs an action and writes it to the action log (success or failure). */
    fun runAction(action: HeruAction, lang: HeruLanguage): ActionResult {
        val result = executor.execute(action, lang)
        val label = executor.label(action)
        appScope.launch { store.appendLog(label, result.ok) }
        return result
    }
}
