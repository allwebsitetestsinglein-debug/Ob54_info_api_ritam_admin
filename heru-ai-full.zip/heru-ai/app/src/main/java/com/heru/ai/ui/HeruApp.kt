package com.heru.ai.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.heru.ai.ui.apps.AppsScreen
import com.heru.ai.ui.automation.AutomationScreen
import com.heru.ai.ui.coding.CodingScreen
import com.heru.ai.ui.home.HomeScreen
import com.heru.ai.ui.misc.ActionLogScreen
import com.heru.ai.ui.misc.MemoryScreen
import com.heru.ai.ui.music.MusicScreen
import com.heru.ai.ui.settings.SettingsScreen
import com.heru.ai.ui.theme.HeruTheme
import com.heru.ai.ui.theme.accentFor

object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val APPS = "apps"
    const val MUSIC = "music"
    const val CODING = "coding"
    const val AUTOMATION = "automation"
    const val MEMORY = "memory"
    const val ACTION_LOG = "actionlog"
}

@Composable
fun HeruApp(settingsVm: SettingsViewModel = viewModel()) {
    val settings by settingsVm.settings.collectAsStateWithLifecycle()
    val accent = accentFor(settings.accent)

    HeruTheme(dark = settings.darkMode, accent = accent) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val nav = rememberNavController()
            val back: () -> Unit = { nav.popBackStack() }
            val go: (String) -> Unit = { nav.navigate(it) }
            NavHost(navController = nav, startDestination = Routes.HOME) {
                composable(Routes.HOME) { HomeScreen(settings = settings, accent = accent, onNavigate = go) }
                composable(Routes.SETTINGS) { SettingsScreen(settings, settingsVm, back, go) }
                composable(Routes.APPS) { AppsScreen(settings.language, back) }
                composable(Routes.MUSIC) { MusicScreen(settings.language, back) }
                composable(Routes.CODING) { CodingScreen(settings, accent, back) }
                composable(Routes.AUTOMATION) { AutomationScreen(settings, back) }
                composable(Routes.MEMORY) { MemoryScreen(back) }
                composable(Routes.ACTION_LOG) { ActionLogScreen(back) }
            }
        }
    }
}
