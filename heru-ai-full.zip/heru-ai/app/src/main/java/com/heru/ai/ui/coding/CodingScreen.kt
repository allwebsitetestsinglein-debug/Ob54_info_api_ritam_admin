package com.heru.ai.ui.coding

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.heru.ai.data.HeruSettings
import com.heru.ai.ui.components.Caption
import com.heru.ai.ui.components.ChoiceRow
import com.heru.ai.ui.components.CodeBg
import com.heru.ai.ui.components.CodeFg
import com.heru.ai.ui.components.CodeVisualTransformation
import com.heru.ai.ui.components.HeruButton
import com.heru.ai.ui.components.Panel
import com.heru.ai.ui.components.RichText
import com.heru.ai.ui.components.ScrollScreen
import com.heru.ai.ui.components.SectionTitle
import com.heru.ai.ui.components.firstCodeBlock

@Composable
fun CodingScreen(settings: HeruSettings, accent: Color, onBack: () -> Unit, vm: CodingViewModel = viewModel()) {
    val clipboard = LocalClipboardManager.current
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importText(uri)
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) vm.exportText(uri)
    }
    val transformation = remember(vm.language) { CodeVisualTransformation(CODING_LANGUAGES[vm.language]) }

    ScrollScreen("Coding mode", onBack) {
        Caption("Gemini code likhta/explain/debug karta hai. HERU kabhi code ya shell command khud run nahi karta.")

        Caption("Task")
        ChoiceRow(CODING_TASKS, vm.task) { vm.task = it }
        Caption("Language")
        ChoiceRow(CODING_LANGUAGES, vm.language) { vm.language = it }

        OutlinedTextField(
            value = vm.instruction,
            onValueChange = { vm.instruction = it },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            label = {
                Text(
                    when (vm.task) {
                        0 -> "Kya banana hai? (description)"
                        3 -> "Compiler/runtime error yahan paste kar"
                        else -> "Extra info (optional)"
                    }
                )
            }
        )

        SectionTitle("Editor")
        OutlinedTextField(
            value = vm.code,
            onValueChange = { vm.code = it },
            modifier = Modifier.fillMaxWidth().heightIn(min = 200.dp, max = 360.dp),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = CodeFg),
            visualTransformation = transformation,
            placeholder = { Text("Yahan code likh ya paste kar…", color = Color(0xFF6B7F99)) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CodeBg,
                unfocusedContainerColor = CodeBg,
                focusedTextColor = CodeFg,
                unfocusedTextColor = CodeFg
            )
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (vm.busy) HeruButton("Stop", { vm.stop() })
            else HeruButton("Gemini se karwao", { vm.run(settings) })
            HeruButton("Copy code", { clipboard.setText(AnnotatedString(vm.code)) }, filled = false)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HeruButton("Import", { importLauncher.launch(arrayOf("*/*")) }, filled = false)
            HeruButton("Export", { exportLauncher.launch(vm.exportName()) }, filled = false, enabled = vm.code.isNotBlank())
            HeruButton("Save snippet", { vm.saveSnippet() }, filled = false)
        }
        if (vm.status.isNotBlank()) Caption(vm.status)

        if (vm.output.isNotBlank()) {
            SectionTitle("Gemini ka jawab")
            Text(
                "AI-generated, test nahi kiya gaya. Chalane se pehle khud review kar.",
                color = MaterialTheme.colorScheme.error,
                fontSize = 12.sp
            )
            Panel {
                RichText(vm.output, MaterialTheme.colorScheme.onSurface, accent)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                val block = firstCodeBlock(vm.output)
                if (block != null) HeruButton("Code editor me daalo", { vm.code = block }, filled = false)
                HeruButton("Poora jawab copy", { clipboard.setText(AnnotatedString(vm.output)) }, filled = false)
            }
        }

        SectionTitle("Saved snippets")
        if (vm.snippets.isEmpty()) Caption("Abhi koi snippet nahi.")
        vm.snippets.forEach { s ->
            Panel {
                Text(s.title, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp)
                Caption(s.language)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HeruButton("Load", { vm.loadSnippet(s) }, filled = false)
                    HeruButton("Delete", { vm.deleteSnippet(s.id) }, filled = false)
                }
            }
        }
    }
}
