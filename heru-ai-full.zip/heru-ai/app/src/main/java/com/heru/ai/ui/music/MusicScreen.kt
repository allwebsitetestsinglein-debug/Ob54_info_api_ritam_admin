package com.heru.ai.ui.music

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.heru.ai.HeruApplication
import com.heru.ai.data.HeruAction
import com.heru.ai.data.HeruLanguage
import com.heru.ai.ui.components.Caption
import com.heru.ai.ui.components.HeruButton
import com.heru.ai.ui.components.Panel
import com.heru.ai.ui.components.ScrollScreen
import com.heru.ai.ui.components.SectionTitle

@Composable
fun MusicScreen(lang: HeruLanguage, onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as HeruApplication
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }

    fun run(a: HeruAction) { status = app.runAction(a, lang).message }

    ScrollScreen("Music & YouTube", onBack) {
        SectionTitle("Search")
        Panel {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Gana / video / topic") }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeruButton("YouTube search", { run(HeruAction.YouTube(query = query.trim())) }, enabled = query.isNotBlank())
                HeruButton("YT Music search", { run(HeruAction.YouTube(query = query.trim(), music = true)) }, enabled = query.isNotBlank(), filled = false)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeruButton("YouTube kholo", { run(HeruAction.YouTube()) }, filled = false)
                HeruButton("YT Music kholo", { run(HeruAction.YouTube(music = true)) }, filled = false)
            }
        }
        if (status.isNotBlank()) Caption(status)
        Caption(
            "Dhyan de: HERU sirf YouTube ka search ya link khol sakta hai. Gana khud play karna padta hai (result pe tap karke). " +
                "Kisi bhi third-party app ke andar playback control, Premium ya DRM bypass nahi hota."
        )
        Caption("Chat me bhi bol sakta hai: \"YouTube par Arijit Singh ka gana chala\" ya \"lo-fi music search karo\".")
    }
}
