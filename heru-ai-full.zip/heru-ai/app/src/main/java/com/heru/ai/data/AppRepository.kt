package com.heru.ai.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Lists launchable apps via PackageManager (needs the <queries> entry in the manifest). */
class AppRepository(private val context: Context) {
    @Volatile
    private var cache: List<AppRef>? = null

    suspend fun apps(force: Boolean = false): List<AppRef> = withContext(Dispatchers.IO) {
        val c = cache
        if (c != null && !force) c else load().also { cache = it }
    }

    private fun load(): List<AppRef> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return list
            .map { AppRef(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}
