package com.heru.ai.ui.coding

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.heru.ai.HeruApplication
import com.heru.ai.ai.GeminiException
import com.heru.ai.ai.Persona
import com.heru.ai.ai.Turn
import com.heru.ai.data.HeruSettings
import com.heru.ai.data.Snippet
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val CODING_LANGUAGES = listOf("Kotlin", "Java", "Python", "JavaScript", "HTML", "CSS", "C++", "SQL")
val CODING_TASKS = listOf("Generate", "Explain", "Debug", "Error")

/** Coding mode state. Nothing here ever executes code or shell commands. */
class CodingViewModel(app: Application) : AndroidViewModel(app) {
    private val h = app as HeruApplication

    var code by mutableStateOf("")
    var instruction by mutableStateOf("")
    var language by mutableStateOf(0)
    var task by mutableStateOf(0)
    var output by mutableStateOf("")
    var busy by mutableStateOf(false)
    var status by mutableStateOf("")
    var snippets by mutableStateOf<List<Snippet>>(emptyList())

    private var job: Job? = null
    private val lang get() = CODING_LANGUAGES[language]

    init { refreshSnippets() }

    private fun buildPrompt(): String? {
        val c = code.trim()
        val ins = instruction.trim()
        val fenced = "```$lang\n$c\n```"
        return when (task) {
            0 -> if (ins.isBlank() && c.isBlank()) null
            else "Write $lang code for this request:\n$ins" + if (c.isNotBlank()) "\n\nExisting code for context:\n$fenced" else ""
            1 -> if (c.isBlank()) null
            else "Explain this $lang code line by line, then summarise what it does:\n$fenced"
            2 -> if (c.isBlank()) null
            else "Find the bugs in this $lang code, explain each one, and give the full fixed code.\n" +
                (if (ins.isNotBlank()) "Extra info: $ins\n" else "") + fenced
            else -> if (ins.isBlank() && c.isBlank()) null
            else "Explain this error in simple words and how to fix it.\nError:\n$ins" +
                if (c.isNotBlank()) "\n\nRelated code:\n$fenced" else ""
        }
    }

    fun run(s: HeruSettings) {
        if (busy) return
        val prompt = buildPrompt()
        if (prompt == null) {
            status = "Pehle code ya description daal."
            return
        }
        job = viewModelScope.launch {
            busy = true
            output = ""
            status = ""
            try {
                val key = withContext(Dispatchers.IO) { h.keyStore.load() }
                if (key.isNullOrBlank()) {
                    status = "Gemini API key set nahi hai (Settings > AI)."
                    return@launch
                }
                val sb = StringBuilder()
                h.gemini.stream(
                    key, s.model, Persona.codingPrompt(s), listOf(Turn("user", prompt)),
                    minOf(s.temperature, 0.7f), maxOf(s.maxTokens, 2048)
                ).collect { chunk ->
                    sb.append(chunk)
                    output = sb.toString()
                }
                if (sb.isBlank()) status = "Gemini ne khaali jawab diya (token limit badha ke dekh)."
            } catch (e: CancellationException) {
                throw e
            } catch (e: GeminiException) {
                status = e.message ?: "Gemini error."
            } catch (e: Exception) {
                status = "Error: ${e.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    fun stop() {
        job?.cancel()
        busy = false
    }

    // ---- snippets ----
    fun refreshSnippets() {
        viewModelScope.launch(Dispatchers.IO) { snippets = h.store.loadSnippets().sortedByDescending { it.id } }
    }

    fun saveSnippet() {
        if (code.isBlank()) {
            status = "Save karne ke liye code likh."
            return
        }
        val firstLine = code.lines().firstOrNull { it.isNotBlank() }?.trim().orEmpty().take(40)
        val snippet = Snippet(System.currentTimeMillis(), firstLine.ifBlank { "Snippet" }, lang, code)
        viewModelScope.launch(Dispatchers.IO) {
            h.store.saveSnippet(snippet)
            snippets = h.store.loadSnippets().sortedByDescending { it.id }
            status = "Snippet save ho gaya (sirf is phone me)."
        }
    }

    fun loadSnippet(s: Snippet) {
        code = s.code
        val i = CODING_LANGUAGES.indexOfFirst { it.equals(s.language, ignoreCase = true) }
        if (i >= 0) language = i
    }

    fun deleteSnippet(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            h.store.deleteSnippet(id)
            snippets = h.store.loadSnippets().sortedByDescending { it.id }
        }
    }

    // ---- import / export (Storage Access Framework, user picks the file) ----
    fun importText(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val bytes = getApplication<Application>().contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes == null) {
                    status = "File khul nahi payi."
                } else if (bytes.size > 1_000_000) {
                    status = "File bahut badi hai (1 MB se kam chahiye)."
                } else {
                    code = String(bytes, Charsets.UTF_8)
                    status = "File import ho gayi."
                }
            } catch (e: Exception) {
                status = "Import fail: ${e.javaClass.simpleName}"
            }
        }
    }

    fun exportText(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use {
                    it.write(code.toByteArray(Charsets.UTF_8))
                }
                status = "File export ho gayi."
            } catch (e: Exception) {
                status = "Export fail: ${e.javaClass.simpleName}"
            }
        }
    }

    fun exportName(): String {
        val ext = when (lang) {
            "Kotlin" -> "kt"; "Java" -> "java"; "Python" -> "py"; "JavaScript" -> "js"
            "HTML" -> "html"; "CSS" -> "css"; "C++" -> "cpp"; else -> "sql"
        }
        return "heru_code.$ext"
    }
}
