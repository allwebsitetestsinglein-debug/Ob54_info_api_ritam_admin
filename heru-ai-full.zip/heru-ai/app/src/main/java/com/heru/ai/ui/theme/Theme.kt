package com.heru.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

val HeruCyan = Color(0xFF00E5FF)
val HeruBlue = Color(0xFF448AFF)
val HeruViolet = Color(0xFFB388FF)

fun accentFor(name: String): Color = when (name) {
    "blue" -> HeruBlue
    "violet" -> HeruViolet
    else -> HeruCyan
}

@Composable
fun HeruTheme(dark: Boolean, accent: Color, content: @Composable () -> Unit) {
    val scheme = if (dark) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color(0xFF00131A),
            background = Color(0xFF05080F),
            onBackground = Color(0xFFE6F6FF),
            surface = Color(0xFF0B1220),
            onSurface = Color(0xFFE6F6FF),
            surfaceVariant = Color(0xFF111B2E),
            onSurfaceVariant = Color(0xFF9FB4C8),
            outline = Color(0xFF2A3A55)
        )
    } else {
        lightColorScheme(
            primary = lerp(accent, Color.Black, 0.4f),
            onPrimary = Color.White,
            background = Color(0xFFF2F7FB),
            onBackground = Color(0xFF0B1220),
            surface = Color.White,
            onSurface = Color(0xFF0B1220),
            surfaceVariant = Color(0xFFE3ECF4),
            onSurfaceVariant = Color(0xFF47586B),
            outline = Color(0xFFB5C4D3)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
