package com.heru.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class TextPart(val isCode: Boolean, val lang: String, val body: String)

/** Splits Markdown into text and ``` fenced code parts. An unclosed fence (streaming) counts as code. */
fun splitFences(text: String): List<TextPart> {
    val segs = text.split("```")
    return segs.mapIndexed { i, seg ->
        if (i % 2 == 0) {
            TextPart(false, "", seg)
        } else {
            val nl = seg.indexOf('\n')
            if (nl < 0) {
                TextPart(true, seg.trim(), "")
            } else {
                val first = seg.substring(0, nl).trim()
                if (first.length <= 15 && !first.contains(' ')) TextPart(true, first, seg.substring(nl + 1).trimEnd())
                else TextPart(true, "", seg.trimEnd())
            }
        }
    }
}

fun firstCodeBlock(text: String): String? =
    splitFences(text).firstOrNull { it.isCode && it.body.isNotBlank() }?.body

private fun markdownInline(s: String, accent: Color): AnnotatedString {
    val lines = s.lines().joinToString("\n") { l ->
        var x = l
        if (Regex("^\\s*#{1,6}\\s+.*").matches(x)) x = "**" + x.replace(Regex("^\\s*#{1,6}\\s+"), "") + "**"
        x.replace(Regex("^(\\s*)[*-] "), "\$1• ")
    }
    val re = Regex("\\*\\*(.+?)\\*\\*|`([^`\\n]+)`")
    return buildAnnotatedString {
        var last = 0
        re.findAll(lines).forEach { m ->
            append(lines.substring(last, m.range.first))
            if (m.groups[1] != null) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(m.groupValues[1]) }
            } else {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = accent.copy(alpha = 0.15f))) {
                    append(m.groupValues[2])
                }
            }
            last = m.range.last + 1
        }
        append(lines.substring(last))
    }
}

@Composable
fun RichText(text: String, color: Color, accent: Color, modifier: Modifier = Modifier) {
    val parts = remember(text) { splitFences(text) }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        parts.forEach { p ->
            if (p.isCode) CodeBlock(p.lang, p.body, accent)
            else if (p.body.isNotBlank()) Text(markdownInline(p.body.trim('\n'), accent), color = color, fontSize = 14.sp)
        }
    }
}

@Composable
fun CodeBlock(lang: String, body: String, accent: Color) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    val highlighted = remember(body, lang) { CodeHighlighter.highlight(body, lang) }
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CodeBg)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 10.dp, end = 4.dp, top = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(lang.ifBlank { "code" }, color = Color(0xFF7F93AB), fontSize = 11.sp, modifier = Modifier.weight(1f))
            Text(
                if (copied) "Copied" else "Copy",
                color = accent,
                fontSize = 12.sp,
                modifier = Modifier
                    .clickable { clipboard.setText(AnnotatedString(body)); copied = true }
                    .padding(8.dp)
            )
        }
        Text(
            highlighted,
            color = CodeFg,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            softWrap = false,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(start = 10.dp, end = 10.dp, bottom = 10.dp)
        )
    }
}
