package com.heru.ai.ui.automation

import android.app.Application
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.heru.ai.HeruApplication
import com.heru.ai.actions.HeruAccessibilityService
import com.heru.ai.data.AppRef
import com.heru.ai.data.GestureKind
import com.heru.ai.data.HeruAction
import com.heru.ai.data.HeruSettings
import com.heru.ai.data.Routine
import com.heru.ai.data.SettingsPage
import com.heru.ai.ui.components.Caption
import com.heru.ai.ui.components.HeruButton
import com.heru.ai.ui.components.Panel
import com.heru.ai.ui.components.ScreenFrame
import com.heru.ai.ui.components.SectionTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AutomationViewModel(app: Application) : AndroidViewModel(app) {
    private val h = app as HeruApplication
    private val _routines = MutableStateFlow<List<Routine>>(emptyList())
    val routines = _routines.asStateFlow()
    private val _apps = MutableStateFlow<List<AppRef>>(emptyList())
    val apps = _apps.asStateFlow()
    private val _status = MutableStateFlow("")
    val status = _status.asStateFlow()

    init {
        viewModelScope.launch {
            _apps.value = h.appRepo.apps()
            reload()
        }
    }

    private fun reload() {
        viewModelScope.launch(Dispatchers.IO) { _routines.value = h.store.loadRoutines() }
    }

    fun run(a: HeruAction, s: HeruSettings) {
        _status.value = h.runAction(a, s.language).message
    }

    fun describe(a: HeruAction, s: HeruSettings): String = h.executor.describe(a, s.language)

    fun saveRoutine(name: String, selected: List<AppRef>) {
        viewModelScope.launch(Dispatchers.IO) {
            h.store.saveRoutine(Routine(System.currentTimeMillis(), name.trim(), selected))
            _routines.value = h.store.loadRoutines()
        }
    }

    fun deleteRoutine(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            h.store.deleteRoutine(id)
            _routines.value = h.store.loadRoutines()
        }
    }
}

@Composable
fun AutomationScreen(settings: HeruSettings, onBack: () -> Unit, vm: AutomationViewModel = viewModel()) {
    val ctx = LocalContext.current
    val routines by vm.routines.collectAsStateWithLifecycle()
    val allApps by vm.apps.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val a11yOn = remember(tick) { HeruAccessibilityService.instance != null }

    var pending by remember { mutableStateOf<HeruAction?>(null) }
    var tapX by remember { mutableStateOf("") }
    var tapY by remember { mutableStateOf("") }
    var creating by remember { mutableStateOf(false) }
    var routineName by remember { mutableStateOf("") }
    var appQuery by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<String>()) }

    fun request(a: HeruAction) {
        if (settings.confirmActions) pending = a else vm.run(a, settings)
    }

    pending?.let { a ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("HERU ye karne wala hai") },
            text = { Text(vm.describe(a, settings)) },
            confirmButton = { TextButton(onClick = { vm.run(a, settings); pending = null }) { Text("Haan, kar") } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Nahi") } }
        )
    }

    val dm = ctx.resources.displayMetrics

    ScreenFrame("Automation", onBack) {
        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Panel {
                    Text("Accessibility (optional)", color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
                    Caption(
                        "Is service se HERU Back/Home/Recents, scroll, swipe aur tap gestures bhej sakta hai, sirf jab tu bole. " +
                            "Ye screen ka content padhta nahi. Android me ise tu khud enable karta hai (Settings > Accessibility > HERU AI), " +
                            "aur kabhi bhi band kar sakta hai. Kuch apps (banking, secure screens) gestures block kar sakte hain."
                    )
                    Caption("Status: ${if (a11yOn) "ON" else "off"}")
                    HeruButton(
                        "Accessibility settings kholo",
                        { vm.run(HeruAction.OpenSettingsPage(SettingsPage.ACCESSIBILITY), settings) },
                        filled = !a11yOn
                    )
                }
            }

            if (a11yOn) {
                item {
                    Panel {
                        Text("Control pad", color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            HeruButton("Back", { request(HeruAction.Gesture(GestureKind.BACK)) }, filled = false)
                            HeruButton("Home", { request(HeruAction.Gesture(GestureKind.HOME)) }, filled = false)
                            HeruButton("Recents", { request(HeruAction.Gesture(GestureKind.RECENTS)) }, filled = false)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            HeruButton("Scroll ↓", { request(HeruAction.Gesture(GestureKind.SCROLL_DOWN)) }, filled = false)
                            HeruButton("Scroll ↑", { request(HeruAction.Gesture(GestureKind.SCROLL_UP)) }, filled = false)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            HeruButton("Swipe ←", { request(HeruAction.Gesture(GestureKind.SWIPE_LEFT)) }, filled = false)
                            HeruButton("Swipe →", { request(HeruAction.Gesture(GestureKind.SWIPE_RIGHT)) }, filled = false)
                        }
                        Caption("Tap (screen ${dm.widthPixels} x ${dm.heightPixels} px):")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = tapX, onValueChange = { tapX = it }, label = { Text("x") },
                                singleLine = true, modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            OutlinedTextField(
                                value = tapY, onValueChange = { tapY = it }, label = { Text("y") },
                                singleLine = true, modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }
                        val x = tapX.toFloatOrNull()
                        val y = tapY.toFloatOrNull()
                        HeruButton("Tap", { if (x != null && y != null) request(HeruAction.Gesture(GestureKind.TAP, x, y)) }, enabled = x != null && y != null)
                        Caption("Chat me bhi bol sakta hai: \"back jao\", \"scroll down\", \"home jao\", \"swipe left\".")
                    }
                }
            }

            if (status.isNotBlank()) item { Caption(status) }

            item { SectionTitle("Routines (apps ka group)") }
            item {
                Caption(
                    "Routine chalane pe HERU selected apps ke launch request ek ke baad ek bhejta hai. " +
                        "Android background se app launch rok sakta hai, to shayad sirf aakhri app dikhe."
                )
            }
            items(routines, key = { it.id }) { r ->
                Panel {
                    Text(r.name, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
                    Caption(r.apps.joinToString { it.label })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HeruButton("Run", { request(HeruAction.RunRoutine(r.name, r.apps)) })
                        HeruButton("Delete", { vm.deleteRoutine(r.id) }, filled = false)
                    }
                }
            }
            if (routines.isEmpty() && !creating) item { Caption("Abhi koi routine nahi.") }

            if (!creating) {
                item { HeruButton("Nayi routine banao", { creating = true }, filled = false) }
            } else {
                item {
                    Panel {
                        OutlinedTextField(
                            value = routineName, onValueChange = { routineName = it },
                            label = { Text("Routine ka naam (jaise padhai)") },
                            singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = appQuery, onValueChange = { appQuery = it },
                            label = { Text("App search") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                        )
                        Caption("${selected.size} app(s) selected")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            HeruButton("Save", {
                                val chosen = allApps.filter { it.pkg in selected }
                                vm.saveRoutine(routineName, chosen)
                                creating = false; routineName = ""; appQuery = ""; selected = emptySet()
                            }, enabled = routineName.isNotBlank() && selected.isNotEmpty())
                            HeruButton("Cancel", { creating = false; selected = emptySet() }, filled = false)
                        }
                    }
                }
                items(allApps.filter { it.label.contains(appQuery.trim(), ignoreCase = true) }, key = { "pick-" + it.pkg }) { a ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selected = if (a.pkg in selected) selected - a.pkg else selected + a.pkg },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = a.pkg in selected,
                            onCheckedChange = { selected = if (it) selected + a.pkg else selected - a.pkg }
                        )
                        Text(a.label, color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}
