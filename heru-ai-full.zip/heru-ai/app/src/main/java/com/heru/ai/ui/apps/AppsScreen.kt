package com.heru.ai.ui.apps

import android.app.Application
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.heru.ai.HeruApplication
import com.heru.ai.data.AppRef
import com.heru.ai.data.HeruAction
import com.heru.ai.data.HeruLanguage
import com.heru.ai.ui.components.Caption
import com.heru.ai.ui.components.ScreenFrame
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AppsViewModel(app: Application) : AndroidViewModel(app) {
    private val h = app as HeruApplication
    private val _apps = MutableStateFlow<List<AppRef>?>(null)
    val apps = _apps.asStateFlow()
    private val _status = MutableStateFlow("")
    val status = _status.asStateFlow()

    init {
        viewModelScope.launch { _apps.value = h.appRepo.apps() }
    }

    fun openApp(app: AppRef, lang: HeruLanguage) {
        _status.value = h.runAction(HeruAction.OpenApp(app), lang).message
    }
}

@Composable
fun AppsScreen(lang: HeruLanguage, onBack: () -> Unit, vm: AppsViewModel = viewModel()) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }

    ScreenFrame("Apps", onBack) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            singleLine = true,
            placeholder = { Text("App search kar…") }
        )
        if (status.isNotBlank()) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { Caption(status) }
        }
        val list = apps
        when {
            list == null -> Column(Modifier.padding(16.dp)) { Caption("Apps load ho rahe hain…") }
            else -> {
                val shown = list.filter { it.label.contains(query.trim(), ignoreCase = true) }
                if (shown.isEmpty()) {
                    Column(Modifier.padding(16.dp)) { Caption("Koi app nahi mila.") }
                } else {
                    LazyColumn(Modifier.weight(1f)) {
                        items(shown, key = { it.pkg }) { a ->
                            Text(
                                a.label,
                                color = MaterialTheme.colorScheme.onBackground,
                                fontSize = 16.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { vm.openApp(a, lang) }
                                    .padding(horizontal = 20.dp, vertical = 14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
