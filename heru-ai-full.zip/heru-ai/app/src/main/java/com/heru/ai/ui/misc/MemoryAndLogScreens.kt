package com.heru.ai.ui.misc

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.heru.ai.HeruApplication
import com.heru.ai.data.LogEntry
import com.heru.ai.data.MemoryItem
import com.heru.ai.ui.components.Caption
import com.heru.ai.ui.components.HeruButton
import com.heru.ai.ui.components.Panel
import com.heru.ai.ui.components.ScrollScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

class MemoryViewModel(app: Application) : AndroidViewModel(app) {
    private val h = app as HeruApplication
    private val _items = MutableStateFlow<List<MemoryItem>>(emptyList())
    val items = _items.asStateFlow()
    private val _log = MutableStateFlow<List<LogEntry>>(emptyList())
    val log = _log.asStateFlow()

    init { reload() }

    fun reload() {
        viewModelScope.launch(Dispatchers.IO) {
            _items.value = h.store.loadMemories()
            _log.value = h.store.loadLog()
        }
    }

    fun add(text: String) = io { h.store.addMemory(text) }
    fun delete(id: Long) = io { h.store.deleteMemory(id) }
    fun clearMemories() = io { h.store.clearMemories() }
    fun clearLog() = io { h.store.clearLog() }

    private fun io(block: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            block()
            _items.value = h.store.loadMemories()
            _log.value = h.store.loadLog()
        }
    }
}

@Composable
fun MemoryScreen(onBack: () -> Unit, vm: MemoryViewModel = viewModel()) {
    val items by vm.items.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }

    ScrollScreen("HERU Memory", onBack) {
        Caption(
            "Yahan sirf wahi cheezein hain jo tune khud save karwayi (chat me \"yaad rakh: ...\" bolke ya yahan add karke). " +
                "Ye local phone me rehti hain, aur chat ke time Gemini ko context ke roop me bheji jaati hain."
        )
        Panel {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Nayi memory") },
                singleLine = true
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeruButton("Add", { vm.add(input); input = "" }, enabled = input.isNotBlank())
                HeruButton("Sab delete", { vm.clearMemories() }, enabled = items.isNotEmpty(), filled = false)
            }
        }
        if (items.isEmpty()) Caption("Abhi koi memory saved nahi hai.")
        items.forEach { m ->
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.text, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    HeruButton("Delete", { vm.delete(m.id) }, filled = false)
                }
            }
        }
    }
}

@Composable
fun ActionLogScreen(onBack: () -> Unit, vm: MemoryViewModel = viewModel()) {
    val log by vm.log.collectAsStateWithLifecycle()
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }

    ScrollScreen("Action history", onBack) {
        Caption("HERU ne jo actions kiye (ya jo fail hue) unki list. Sirf is phone me save hoti hai.")
        HeruButton("Clear history", { vm.clearLog() }, enabled = log.isNotEmpty(), filled = false)
        if (log.isEmpty()) Caption("Abhi tak koi action nahi.")
        log.forEach { e ->
            Panel {
                Text(
                    (if (e.ok) "✓ " else "✗ ") + e.text,
                    color = if (e.ok) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
                    fontSize = 14.sp
                )
                Caption(fmt.format(Date(e.time)))
            }
        }
    }
}
