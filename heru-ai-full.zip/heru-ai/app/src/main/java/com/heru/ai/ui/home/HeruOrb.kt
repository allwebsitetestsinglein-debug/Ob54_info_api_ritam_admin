package com.heru.ai.ui.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

/**
 * Glowing HERU core. animationLevel 0 = static (no animation loop runs at all, saves battery),
 * 1 = normal, 2 = rich (extra ring).
 */
@Composable
fun HeruOrb(
    state: HeruState,
    accent: Color,
    animationLevel: Int,
    modifier: Modifier = Modifier
) {
    if (animationLevel <= 0) {
        OrbCanvas(0f, 1f, accent, 3, modifier)
    } else {
        val active = state != HeruState.IDLE
        val transition = rememberInfiniteTransition(label = "orb")
        val phase by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(if (active) 2500 else 8000, easing = LinearEasing)),
            label = "phase"
        )
        val pulse by transition.animateFloat(
            initialValue = 0.94f,
            targetValue = 1.06f,
            animationSpec = infiniteRepeatable(
                tween(if (active) 800 else 2600, easing = FastOutSlowInEasing),
                RepeatMode.Reverse
            ),
            label = "pulse"
        )
        OrbCanvas(phase, pulse, accent, if (animationLevel >= 2) 4 else 3, modifier)
    }
}

@Composable
private fun OrbCanvas(phase: Float, pulse: Float, accent: Color, rings: Int, modifier: Modifier) {
    Canvas(modifier = modifier.aspectRatio(1f)) {
        val c = center
        val r = size.minDimension / 2f

        drawCircle(
            brush = Brush.radialGradient(
                listOf(accent.copy(alpha = 0.35f), Color.Transparent),
                center = c,
                radius = r
            ),
            radius = r,
            center = c
        )

        val coreR = r * 0.42f * pulse
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.95f), accent, accent.copy(alpha = 0.15f)),
                center = c,
                radius = coreR
            ),
            radius = coreR,
            center = c
        )

        for (i in 0 until rings) {
            val rr = r * (0.58f + 0.12f * i)
            val dir = if (i % 2 == 0) 1f else -1f
            rotate(degrees = phase * 360f * dir + i * 47f, pivot = c) {
                drawArc(
                    color = accent.copy(alpha = (0.9f - 0.18f * i).coerceAtLeast(0.2f)),
                    startAngle = 0f,
                    sweepAngle = 90f + i * 35f,
                    useCenter = false,
                    topLeft = Offset(c.x - rr, c.y - rr),
                    size = Size(rr * 2, rr * 2),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
    }
}
