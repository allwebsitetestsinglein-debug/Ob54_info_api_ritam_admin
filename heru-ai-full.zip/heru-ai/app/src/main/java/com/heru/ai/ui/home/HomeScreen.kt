package com.heru.ai.ui.home

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.heru.ai.data.ActionChoice
import com.heru.ai.data.ChatMessage
import com.heru.ai.data.HeruAction
import com.heru.ai.data.HeruSettings
import com.heru.ai.ui.Routes
import com.heru.ai.ui.components.RichText

private data class QuickAction(val icon: String, val label: String, val route: String?)

private val quickActions = listOf(
    QuickAction("📱", "Apps", Routes.APPS),
    QuickAction("🎵", "Music", Routes.MUSIC),
    QuickAction("💻", "Coding", Routes.CODING),
    QuickAction("📷", "Camera", null),
    QuickAction("⚙️", "Settings", Routes.SETTINGS),
    QuickAction("🤖", "Automation", Routes.AUTOMATION)
)

@Composable
fun HomeScreen(
    settings: HeruSettings,
    accent: Color,
    onNavigate: (String) -> Unit,
    vm: HomeViewModel = viewModel()
) {
    val ctx = LocalContext.current
    val messages by vm.messages.collectAsStateWithLifecycle()
    val state by vm.state.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val pad = if (settings.compactLayout) 10.dp else 16.dp

    LaunchedEffect(Unit) { vm.navEvents.collect { onNavigate(it) } }
    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) listState.scrollToItem(messages.lastIndex)
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.toggleListening() else vm.onMicPermissionDenied()
    }
    val onMic: () -> Unit = {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.toggleListening() else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = pad)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "HERU AI",
                color = accent,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                "⚙️",
                fontSize = 22.sp,
                modifier = Modifier.clip(CircleShape).clickable { onNavigate(Routes.SETTINGS) }.padding(8.dp)
            )
        }

        Box(
            modifier = Modifier.fillMaxWidth().weight(if (settings.compactLayout) 0.9f else 1.2f),
            contentAlignment = Alignment.Center
        ) {
            HeruOrb(
                state = state,
                accent = accent,
                animationLevel = settings.animationLevel,
                modifier = Modifier.fillMaxSize().padding(8.dp)
            )
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(
                        if (state == HeruState.LISTENING) accent.copy(alpha = 0.6f)
                        else MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                    )
                    .clickable(onClick = onMic),
                contentAlignment = Alignment.Center
            ) { Text(if (state == HeruState.LISTENING) "⏹" else "🎤", fontSize = 28.sp) }
        }

        Row(
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(state.label, color = accent, fontSize = 13.sp, letterSpacing = 2.sp)
            if (state != HeruState.IDLE) {
                Text(
                    "  ⏹ Stop",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).clickable { vm.stopAll() }.padding(6.dp)
                )
            }
        }
        if (partial.isNotBlank()) {
            Text(
                partial,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
                fontStyle = FontStyle.Italic,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp)
            )
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(messages, key = { it.id }) { m ->
                MessageBubble(m, accent) { choice -> vm.onChoice(m.id, choice) }
            }
        }

        Spacer(Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(quickActions) { qa ->
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable {
                            if (qa.route != null) onNavigate(qa.route) else vm.runDirect(HeruAction.OpenCamera)
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(qa.icon, fontSize = 16.sp)
                    Spacer(Modifier.size(6.dp))
                    Text(qa.label, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
                }
            }
        }

        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            placeholder = { Text("HERU se baat kar…") },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { vm.send(input); input = "" }),
            trailingIcon = {
                Text(
                    "➤",
                    color = accent,
                    fontSize = 20.sp,
                    modifier = Modifier.clip(CircleShape).clickable { vm.send(input); input = "" }.padding(10.dp)
                )
            }
        )
    }
}

@Composable
private fun MessageBubble(m: ChatMessage, accent: Color, onChoice: (ActionChoice) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (m.fromUser) Alignment.End else Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 330.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (m.fromUser) accent.copy(alpha = 0.22f) else cs.surfaceVariant)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            when {
                m.fromUser -> Text(m.text, color = cs.onSurface, fontSize = 14.sp)
                m.isNote -> Text(m.text, color = cs.onSurfaceVariant, fontSize = 14.sp, fontStyle = FontStyle.Italic)
                m.text.isEmpty() && m.streaming -> Text("…", color = cs.onSurfaceVariant, fontSize = 14.sp)
                else -> RichText(m.text, cs.onSurface, accent)
            }
        }
        if (m.choices.isNotEmpty()) {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                m.choices.forEach { c ->
                    Text(
                        c.label,
                        color = if (c.action != null) cs.onPrimary else cs.onSurface,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (c.action != null) accent else cs.surfaceVariant)
                            .clickable { onChoice(c) }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
            }
        }
    }
}
