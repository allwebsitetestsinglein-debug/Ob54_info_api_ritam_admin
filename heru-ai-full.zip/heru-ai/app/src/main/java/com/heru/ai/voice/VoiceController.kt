package com.heru.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Wraps Android SpeechRecognizer (speech-to-text) and TextToSpeech. Must be used from the main thread. */
class VoiceController(private val context: Context) {

    interface Callback {
        fun onListening(active: Boolean)
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onSpeaking(active: Boolean)
        fun onError(msg: String)
    }

    var callback: Callback? = null

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pending = mutableListOf<() -> Unit>()

    // ---------- speech to text ----------

    fun recognitionAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(languageTag: String) {
        stopSpeaking()
        if (!recognitionAvailable()) {
            callback?.onError("Is phone me speech recognition available nahi hai (Google app / voice service check kar).")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(listener)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        callback?.onListening(true)
        r.startListening(i)
    }

    /** Stop recording and deliver whatever was heard. */
    fun stopListening() {
        recognizer?.stopListening()
    }

    /** Abort without delivering results. */
    fun cancelListening() {
        recognizer?.cancel()
        callback?.onListening(false)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            callback?.onListening(false)
            if (error != SpeechRecognizer.ERROR_CLIENT) callback?.onError(describe(error))
        }

        override fun onResults(results: Bundle?) {
            callback?.onListening(false)
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) callback?.onFinal(text) else callback?.onError("Kuch samajh nahi aaya, dobara bol.")
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) callback?.onPartial(text)
        }
    }

    private fun describe(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch suna nahi, dobara bol."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission chahiye."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition ke liye network problem."
        SpeechRecognizer.ERROR_AUDIO -> "Microphone / audio error."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy hai, thodi der baad try kar."
        SpeechRecognizer.ERROR_SERVER -> "Speech recognition server error."
        else -> "Voice input error ($code)."
    }

    // ---------- text to speech ----------

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) { main.post { callback?.onSpeaking(true) } }
        override fun onDone(utteranceId: String?) { main.post { callback?.onSpeaking(false) } }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) { main.post { callback?.onSpeaking(false) } }

        override fun onError(utteranceId: String?, errorCode: Int) { main.post { callback?.onSpeaking(false) } }
        override fun onStop(utteranceId: String?, interrupted: Boolean) { main.post { callback?.onSpeaking(false) } }
    }

    private fun ensureTts(then: () -> Unit) {
        if (ttsReady) {
            then()
            return
        }
        pending.add(then)
        if (tts == null) {
            val engine = TextToSpeech(context) { status ->
                main.post {
                    if (status == TextToSpeech.SUCCESS) {
                        ttsReady = true
                        val jobs = pending.toList()
                        pending.clear()
                        jobs.forEach { it() }
                    } else {
                        pending.clear()
                        tts = null
                        callback?.onError("Text-to-speech engine start nahi hua.")
                    }
                }
            }
            engine.setOnUtteranceProgressListener(progress)
            tts = engine
        }
    }

    fun speak(text: String, languageTag: String, rate: Float, pitch: Float, voiceName: String) {
        val clean = speakable(text)
        if (clean.isBlank()) return
        ensureTts {
            val t = tts ?: return@ensureTts
            val locale = Locale.forLanguageTag(languageTag)
            val r = t.setLanguage(locale)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                callback?.onError("TTS me '$languageTag' voice installed nahi hai. Phone ki Text-to-speech settings me voice data download kar.")
                return@ensureTts
            }
            if (voiceName.isNotBlank()) {
                t.voices?.firstOrNull { it.name == voiceName && it.locale.language == locale.language }
                    ?.let { t.voice = it }
            }
            t.setSpeechRate(rate)
            t.setPitch(pitch)
            t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "heru-${System.currentTimeMillis()}")
        }
    }

    fun stopSpeaking() {
        tts?.stop()
        callback?.onSpeaking(false)
    }

    /** Lists installed TTS voices for the given language (loads the engine first if needed). */
    fun loadVoices(languageTag: String, onLoaded: (List<String>) -> Unit) {
        ensureTts {
            val lang = Locale.forLanguageTag(languageTag).language
            val names = tts?.voices?.filter { it.locale.language == lang }?.map { it.name }?.sorted().orEmpty()
            onLoaded(names)
        }
    }

    fun shutdown() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }

    private fun speakable(s: String): String {
        var t = s.replace(Regex("```[\\s\\S]*?(```|\$)"), " ")
        t = t.replace(Regex("https?://\\S+"), " ")
        t = t.replace(Regex("[*_#`>]"), "")
        t = t.trim()
        val max = (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(500)
        return if (t.length > max) t.substring(0, max) else t
    }
}
