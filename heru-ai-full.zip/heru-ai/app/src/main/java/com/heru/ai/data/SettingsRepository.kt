package com.heru.ai.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "heru_settings")

enum class HeruLanguage(val label: String, val sttTag: String, val ttsTag: String) {
    HINGLISH("Hinglish", "hi-IN", "en-IN"),
    HINDI("Hindi", "hi-IN", "hi-IN"),
    ENGLISH("English", "en-IN", "en-IN")
}

enum class Personality(val label: String, val prompt: String) {
    BEST_FRIEND("Best friend", "Personality: a warm, loyal best friend who talks casually and supports the user."),
    FUNNY("Funny", "Personality: a witty best friend. Use light humour and playful banter, but stay helpful and respectful."),
    MENTOR("Calm mentor", "Personality: a calm, wise mentor. Be patient, encouraging and clear."),
    PROFESSIONAL("Professional", "Personality: polite, concise and professional, but still friendly.")
}

enum class ResponseStyle(val label: String, val prompt: String) {
    SHORT("Short", "Keep answers short (2-4 sentences) unless the user asks for detail."),
    BALANCED("Balanced", "Give balanced answers: complete but not long."),
    DETAILED("Detailed", "Give detailed, well-structured answers with examples when useful.")
}

data class HeruSettings(
    val language: HeruLanguage = HeruLanguage.HINGLISH,
    val darkMode: Boolean = true,
    val accent: String = "cyan",
    val animationLevel: Int = 1,
    val compactLayout: Boolean = false,
    val voiceReplies: Boolean = true,
    val confirmActions: Boolean = true,
    val model: String = "gemini-2.5-flash",
    val temperature: Float = 0.8f,
    val maxTokens: Int = 2048,
    val personality: Personality = Personality.BEST_FRIEND,
    val style: ResponseStyle = ResponseStyle.BALANCED,
    val customPrompt: String = "",
    val saveHistory: Boolean = true,
    val ttsRate: Float = 1.0f,
    val ttsPitch: Float = 1.0f,
    val ttsVoice: String = ""
)

object Keys {
    val LANGUAGE = stringPreferencesKey("language")
    val DARK = booleanPreferencesKey("dark_mode")
    val ACCENT = stringPreferencesKey("accent")
    val ANIM = intPreferencesKey("animation_level")
    val COMPACT = booleanPreferencesKey("compact_layout")
    val VOICE = booleanPreferencesKey("voice_replies")
    val CONFIRM = booleanPreferencesKey("confirm_actions")
    val MODEL = stringPreferencesKey("model")
    val TEMPERATURE = floatPreferencesKey("temperature")
    val MAX_TOKENS = intPreferencesKey("max_tokens")
    val PERSONALITY = stringPreferencesKey("personality")
    val STYLE = stringPreferencesKey("style")
    val CUSTOM = stringPreferencesKey("custom_prompt")
    val HISTORY = booleanPreferencesKey("save_history")
    val RATE = floatPreferencesKey("tts_rate")
    val PITCH = floatPreferencesKey("tts_pitch")
    val VOICE_NAME = stringPreferencesKey("tts_voice")
}

private inline fun <reified E : Enum<E>> enumOr(name: String?, default: E): E =
    enumValues<E>().firstOrNull { it.name == name } ?: default

class SettingsRepository(private val context: Context) {

    val settings: Flow<HeruSettings> = context.dataStore.data.map { p ->
        val d = HeruSettings()
        HeruSettings(
            language = enumOr(p[Keys.LANGUAGE], d.language),
            darkMode = p[Keys.DARK] ?: d.darkMode,
            accent = p[Keys.ACCENT] ?: d.accent,
            animationLevel = (p[Keys.ANIM] ?: d.animationLevel).coerceIn(0, 2),
            compactLayout = p[Keys.COMPACT] ?: d.compactLayout,
            voiceReplies = p[Keys.VOICE] ?: d.voiceReplies,
            confirmActions = p[Keys.CONFIRM] ?: d.confirmActions,
            model = p[Keys.MODEL] ?: d.model,
            temperature = (p[Keys.TEMPERATURE] ?: d.temperature).coerceIn(0f, 2f),
            maxTokens = (p[Keys.MAX_TOKENS] ?: d.maxTokens).coerceIn(64, 8192),
            personality = enumOr(p[Keys.PERSONALITY], d.personality),
            style = enumOr(p[Keys.STYLE], d.style),
            customPrompt = p[Keys.CUSTOM] ?: d.customPrompt,
            saveHistory = p[Keys.HISTORY] ?: d.saveHistory,
            ttsRate = (p[Keys.RATE] ?: d.ttsRate).coerceIn(0.5f, 2f),
            ttsPitch = (p[Keys.PITCH] ?: d.ttsPitch).coerceIn(0.5f, 2f),
            ttsVoice = p[Keys.VOICE_NAME] ?: d.ttsVoice
        )
    }

    suspend fun <T> put(key: Preferences.Key<T>, value: T) {
        context.dataStore.edit { it[key] = value }
    }

    suspend fun resetAll() {
        context.dataStore.edit { it.clear() }
    }
}
