package com.heru.ai.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

val CodeBg = Color(0xFF0A101C)
val CodeFg = Color(0xFFD6E4F0)

/** Small regex-based syntax highlighter (keywords, strings, numbers, comments). Good enough for display, not a parser. */
object CodeHighlighter {
    private val keyword = SpanStyle(color = Color(0xFFC792EA))
    private val string = SpanStyle(color = Color(0xFFC3E88D))
    private val number = SpanStyle(color = Color(0xFFF78C6C))
    private val comment = SpanStyle(color = Color(0xFF6B7F99))

    private val keywords = setOf(
        "fun", "val", "var", "class", "object", "interface", "if", "else", "when", "for", "while", "do", "return",
        "import", "package", "private", "public", "protected", "static", "final", "void", "int", "long", "float",
        "double", "boolean", "char", "new", "this", "super", "null", "true", "false", "try", "catch", "finally",
        "throw", "throws", "extends", "implements", "override", "suspend", "data", "sealed", "enum", "def", "self",
        "lambda", "None", "True", "False", "from", "as", "in", "is", "with", "pass", "elif", "async", "await",
        "function", "const", "let", "export", "default", "typeof", "struct", "namespace", "using", "include",
        "break", "continue", "switch", "case", "string", "bool", "auto", "template", "typename", "virtual"
    )
    private val sqlKeywords = setOf(
        "select", "from", "where", "insert", "update", "delete", "create", "table", "join", "on", "group", "by",
        "order", "limit", "and", "or", "not", "into", "values", "set", "as", "null", "primary", "key", "left",
        "right", "inner", "outer", "having", "distinct", "alter", "drop", "index", "count", "sum", "avg"
    )

    private const val STRING_RE = """\x22(?:\\.|[^\x22\\\n])*\x22|\x27(?:\\.|[^\x27\\\n])*\x27"""
    private const val NUMBER_RE = """\b\d+(?:\.\d+)?\b"""
    private const val WORD_RE = """\b[A-Za-z_][A-Za-z0-9_]*\b"""

    private fun commentRe(lang: String): String = when (lang.lowercase()) {
        "python", "py", "bash", "sh", "yaml", "yml" -> """#[^\n]*"""
        "sql" -> """--[^\n]*|/\*[\s\S]*?\*/"""
        "html", "xml" -> """<!--[\s\S]*?-->"""
        else -> """//[^\n]*|/\*[\s\S]*?\*/"""
    }

    private val cache = HashMap<String, Regex>()

    private fun regexFor(lang: String): Regex = cache.getOrPut(lang.lowercase()) {
        Regex("(" + commentRe(lang) + ")|(" + STRING_RE + ")|(" + NUMBER_RE + ")|(" + WORD_RE + ")")
    }

    fun highlight(code: String, lang: String): AnnotatedString {
        val isSql = lang.equals("sql", ignoreCase = true)
        return buildAnnotatedString {
            append(code)
            regexFor(lang).findAll(code).forEach { m ->
                val style = when {
                    m.groups[1] != null -> comment
                    m.groups[2] != null -> string
                    m.groups[3] != null -> number
                    else -> {
                        val w = m.value
                        val isKw = if (isSql) w.lowercase() in sqlKeywords else w in keywords
                        if (isKw) keyword else null
                    }
                }
                if (style != null) addStyle(style, m.range.first, m.range.last + 1)
            }
        }
    }
}

/** Lets a text field display highlighted code while keeping the raw text unchanged. */
class CodeVisualTransformation(private val lang: String) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText =
        TransformedText(CodeHighlighter.highlight(text.text, lang), OffsetMapping.Identity)
}
