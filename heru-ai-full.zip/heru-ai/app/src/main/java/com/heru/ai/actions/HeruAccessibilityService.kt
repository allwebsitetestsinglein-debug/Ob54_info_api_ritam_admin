package com.heru.ai.actions

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.heru.ai.data.GestureKind

/**
 * Optional service. It only performs gestures that the user requested from HERU's UI or chat.
 * It does NOT request window content access, so it cannot read what is on your screen.
 */
class HeruAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* intentionally ignored */ }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** Returns true if Android accepted the request (not a guarantee the target app reacted). */
    fun perform(kind: GestureKind, x: Float, y: Float): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (kind) {
            GestureKind.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            GestureKind.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            GestureKind.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            GestureKind.SCROLL_DOWN -> swipe(w / 2, h * 0.7f, w / 2, h * 0.3f, 350)
            GestureKind.SCROLL_UP -> swipe(w / 2, h * 0.3f, w / 2, h * 0.7f, 350)
            GestureKind.SWIPE_LEFT -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2, 300)
            GestureKind.SWIPE_RIGHT -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2, 300)
            GestureKind.TAP -> dispatch(Path().apply { moveTo(x, y) }, 60)
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean =
        dispatch(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, durationMs)

    private fun dispatch(path: Path, durationMs: Long): Boolean {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    companion object {
        @Volatile
        var instance: HeruAccessibilityService? = null
    }
}
