package com.heru.ai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Simple private JSON-file storage (chat, memories, snippets, action log, routines). */
class LocalStore(context: Context) {
    private val dir: File = context.filesDir
    private val lock = Any()

    private fun read(name: String): JSONArray = synchronized(lock) {
        val f = File(dir, name)
        if (!f.exists()) JSONArray() else try {
            JSONArray(f.readText())
        } catch (e: Exception) {
            JSONArray()
        }
    }

    private fun write(name: String, arr: JSONArray) {
        synchronized(lock) {
            val tmp = File(dir, "$name.tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(File(dir, name))
        }
    }

    private fun delete(name: String) {
        synchronized(lock) { File(dir, name).delete() }
    }

    private inline fun <T> JSONArray.mapObjects(f: (JSONObject) -> T): List<T> =
        (0 until length()).map { f(getJSONObject(it)) }

    // ---- chat ----
    fun loadChat(): List<ChatMessage> = read("chat.json").mapObjects {
        ChatMessage(it.getLong("id"), it.getString("text"), it.getBoolean("user"), it.optBoolean("note"))
    }

    fun saveChat(list: List<ChatMessage>) {
        val arr = JSONArray()
        list.takeLast(200).forEach {
            arr.put(JSONObject().put("id", it.id).put("text", it.text).put("user", it.fromUser).put("note", it.isNote))
        }
        write("chat.json", arr)
    }

    fun clearChat() = delete("chat.json")

    // ---- memory ----
    fun loadMemories(): List<MemoryItem> =
        read("memory.json").mapObjects { MemoryItem(it.getLong("id"), it.getString("text")) }

    fun addMemory(text: String) {
        val t = text.trim().take(300)
        if (t.isEmpty()) return
        val list = loadMemories()
        if (list.any { it.text.equals(t, ignoreCase = true) }) return
        saveMemories(list + MemoryItem(System.currentTimeMillis(), t))
    }

    fun deleteMemory(id: Long) = saveMemories(loadMemories().filter { it.id != id })
    fun clearMemories() = delete("memory.json")

    private fun saveMemories(list: List<MemoryItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text)) }
        write("memory.json", arr)
    }

    // ---- snippets ----
    fun loadSnippets(): List<Snippet> = read("snippets.json").mapObjects {
        Snippet(it.getLong("id"), it.getString("title"), it.getString("lang"), it.getString("code"))
    }

    fun saveSnippet(s: Snippet) = writeSnippets(loadSnippets().filter { it.id != s.id } + s)
    fun deleteSnippet(id: Long) = writeSnippets(loadSnippets().filter { it.id != id })

    private fun writeSnippets(list: List<Snippet>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("lang", it.language).put("code", it.code))
        }
        write("snippets.json", arr)
    }

    // ---- action log ----
    fun loadLog(): List<LogEntry> =
        read("actionlog.json").mapObjects { LogEntry(it.getLong("t"), it.getString("text"), it.getBoolean("ok")) }
            .sortedByDescending { it.time }

    fun appendLog(text: String, ok: Boolean) {
        val list = (loadLog() + LogEntry(System.currentTimeMillis(), text, ok)).sortedByDescending { it.time }.take(300)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.time).put("text", it.text).put("ok", it.ok)) }
        write("actionlog.json", arr)
    }

    fun clearLog() = delete("actionlog.json")

    // ---- routines ----
    fun loadRoutines(): List<Routine> = read("routines.json").mapObjects { o ->
        val apps = o.getJSONArray("apps").mapObjects { AppRef(it.getString("pkg"), it.getString("label")) }
        Routine(o.getLong("id"), o.getString("name"), apps)
    }

    fun saveRoutine(r: Routine) = writeRoutines(loadRoutines().filter { it.id != r.id } + r)
    fun deleteRoutine(id: Long) = writeRoutines(loadRoutines().filter { it.id != id })

    private fun writeRoutines(list: List<Routine>) {
        val arr = JSONArray()
        list.forEach { r ->
            val apps = JSONArray()
            r.apps.forEach { apps.put(JSONObject().put("pkg", it.pkg).put("label", it.label)) }
            arr.put(JSONObject().put("id", r.id).put("name", r.name).put("apps", apps))
        }
        write("routines.json", arr)
    }
}
