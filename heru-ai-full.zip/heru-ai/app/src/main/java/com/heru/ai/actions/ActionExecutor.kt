package com.heru.ai.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import com.heru.ai.data.HeruAction
import com.heru.ai.data.HeruLanguage
import com.heru.ai.data.L
import com.heru.ai.data.SettingsPage
import java.net.URLEncoder

data class ActionResult(val ok: Boolean, val message: String)

/** Performs real Android actions with intents. Never reports success unless Android accepted the request. */
class ActionExecutor(private val context: Context) {

    fun label(a: HeruAction): String = when (a) {
        is HeruAction.OpenApp -> "Open app: ${a.app.label}"
        is HeruAction.OpenSettingsPage -> "Open settings page: ${a.page.label}"
        is HeruAction.YouTube -> {
            val target = if (a.music) "YouTube Music" else "YouTube"
            when {
                a.url != null -> "Open $target link"
                a.query.isNullOrBlank() -> "Open $target"
                else -> "$target search: ${a.query}"
            }
        }
        is HeruAction.Gesture -> "Gesture: ${a.kind.label}"
        is HeruAction.RunRoutine -> "Routine: ${a.name}"
        HeruAction.OpenCamera -> "Open camera app"
        is HeruAction.Navigate -> "Go to ${a.route}"
    }

    fun describe(a: HeruAction, lang: HeruLanguage): String = when (a) {
        is HeruAction.OpenApp -> L(lang, "${a.app.label} khol doon?", "Open ${a.app.label}?")
        is HeruAction.OpenSettingsPage -> L(lang, "${a.page.label} ka settings page khol doon?", "Open the ${a.page.label} settings page?")
        is HeruAction.YouTube -> when {
            a.url != null -> L(lang, "Ye YouTube link khol doon?", "Open this YouTube link?")
            a.query.isNullOrBlank() -> L(lang, "YouTube khol doon?", "Open YouTube?")
            else -> L(lang, "YouTube pe '${a.query}' search khol doon? (play tu khud karna)", "Open a YouTube search for '${a.query}'? (you press play)")
        }
        is HeruAction.Gesture -> L(
            lang,
            "Accessibility se '${a.kind.label}' gesture bhejun?",
            "Send the '${a.kind.label}' gesture through Accessibility?"
        )
        is HeruAction.RunRoutine -> L(
            lang,
            "Routine '${a.name}' chalau? (${a.apps.size} apps)",
            "Run routine '${a.name}'? (${a.apps.size} apps)"
        )
        HeruAction.OpenCamera -> L(lang, "Camera app khol doon?", "Open the camera app?")
        is HeruAction.Navigate -> ""
    }

    fun execute(a: HeruAction, lang: HeruLanguage): ActionResult = try {
        when (a) {
            is HeruAction.OpenApp -> openApp(a, lang)
            is HeruAction.OpenSettingsPage -> openSettings(a.page, lang)
            is HeruAction.YouTube -> youTube(a, lang)
            is HeruAction.Gesture -> gesture(a, lang)
            is HeruAction.RunRoutine -> routine(a, lang)
            HeruAction.OpenCamera -> {
                start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                ActionResult(true, L(lang, "Camera app khol diya.", "Opened the camera app."))
            }
            is HeruAction.Navigate -> ActionResult(true, "")
        }
    } catch (e: ActivityNotFoundException) {
        ActionResult(false, L(lang, "Ye action is phone pe supported nahi hai (app/page nahi mila).", "That action isn't supported on this phone (no app/page found)."))
    } catch (e: SecurityException) {
        ActionResult(false, L(lang, "Android ne permission nahi di.", "Android denied permission for that action."))
    } catch (e: Exception) {
        ActionResult(false, L(lang, "Action fail ho gaya: ${e.javaClass.simpleName}", "Action failed: ${e.javaClass.simpleName}"))
    }

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
    }

    private fun openApp(a: HeruAction.OpenApp, lang: HeruLanguage): ActionResult {
        val i = context.packageManager.getLaunchIntentForPackage(a.app.pkg)
            ?: return ActionResult(false, L(lang, "${a.app.label} installed nahi hai ya khul nahi sakta.", "${a.app.label} isn't installed or can't be launched."))
        start(i)
        return ActionResult(true, L(lang, "${a.app.label} khol diya.", "Opened ${a.app.label}."))
    }

    private fun openSettings(page: SettingsPage, lang: HeruLanguage): ActionResult {
        val i = when (page) {
            SettingsPage.MAIN -> Intent(Settings.ACTION_SETTINGS)
            SettingsPage.WIFI -> Intent(Settings.ACTION_WIFI_SETTINGS)
            SettingsPage.BLUETOOTH -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            SettingsPage.DISPLAY -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            SettingsPage.SOUND -> Intent(Settings.ACTION_SOUND_SETTINGS)
            SettingsPage.BATTERY -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            SettingsPage.LOCATION -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            SettingsPage.APPS -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            SettingsPage.AIRPLANE -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            SettingsPage.ACCESSIBILITY -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            SettingsPage.APP_DETAILS -> Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.packageName, null)
            )
        }
        start(i)
        return ActionResult(
            true,
            L(
                lang,
                "${page.label} ka page khol diya. Direct on/off Android apps ko allow nahi karta, toggle tu khud kar.",
                "Opened the ${page.label} page. Android doesn't let apps toggle this directly, so flip it yourself."
            )
        )
    }

    private fun youTube(a: HeruAction.YouTube, lang: HeruLanguage): ActionResult {
        val enc = URLEncoder.encode(a.query.orEmpty(), "UTF-8")
        val uri = when {
            a.url != null -> a.url
            a.query.isNullOrBlank() -> if (a.music) "https://music.youtube.com" else "https://www.youtube.com"
            a.music -> "https://music.youtube.com/search?q=$enc"
            else -> "https://www.youtube.com/results?search_query=$enc"
        }
        val pkg = if (a.music) "com.google.android.apps.youtube.music" else "com.google.android.youtube"
        val installed = context.packageManager.getLaunchIntentForPackage(pkg) != null
        val view = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
        if (installed) {
            try {
                start(Intent(view).setPackage(pkg))
                return ActionResult(true, youTubeMsg(a, lang, "app"))
            } catch (e: ActivityNotFoundException) {
                // fall through to browser
            }
        }
        start(Intent(view))
        return ActionResult(true, youTubeMsg(a, lang, "browser"))
    }

    private fun youTubeMsg(a: HeruAction.YouTube, lang: HeruLanguage, where: String): String {
        val place = if (where == "app") L(lang, "app me", "in the app") else L(lang, "browser me", "in the browser")
        return if (a.query.isNullOrBlank()) {
            L(lang, "YouTube $place khol diya.", "Opened YouTube $place.")
        } else {
            L(
                lang,
                "'${a.query}' ka search $place khol diya. Main sirf search khol sakta hoon, play tu result pe tap karke kar.",
                "Opened the search for '${a.query}' $place. I can only open the search; tap a result to play it."
            )
        }
    }

    private fun gesture(a: HeruAction.Gesture, lang: HeruLanguage): ActionResult {
        val svc = HeruAccessibilityService.instance
            ?: return ActionResult(
                false,
                L(
                    lang,
                    "Accessibility service on nahi hai. Automation screen se enable kar.",
                    "The accessibility service is off. Enable it from the Automation screen."
                )
            )
        val accepted = svc.perform(a.kind, a.x, a.y)
        return if (accepted) {
            ActionResult(true, L(lang, "'${a.kind.label}' gesture bhej diya (result app pe depend karta hai).", "Sent the '${a.kind.label}' gesture (the result depends on the app)."))
        } else {
            ActionResult(false, L(lang, "Android ne '${a.kind.label}' gesture accept nahi kiya.", "Android didn't accept the '${a.kind.label}' gesture."))
        }
    }

    private fun routine(a: HeruAction.RunRoutine, lang: HeruLanguage): ActionResult {
        var sent = 0
        val failed = ArrayList<String>()
        for (app in a.apps) {
            val i = context.packageManager.getLaunchIntentForPackage(app.pkg)
            if (i == null) {
                failed.add(app.label)
            } else {
                try {
                    start(i)
                    sent++
                } catch (e: Exception) {
                    failed.add(app.label)
                }
            }
        }
        val msg = L(
            lang,
            "Routine '${a.name}': $sent app(s) ko launch request bheji. Android background launches rok sakta hai, to shayad sirf aakhri app dikhe.",
            "Routine '${a.name}': sent launch requests for $sent app(s). Android may block background launches, so you might only see the last one."
        )
        return if (failed.isEmpty()) ActionResult(sent > 0, msg)
        else ActionResult(sent > 0, msg + " " + L(lang, "Nahi khule: ${failed.joinToString()}.", "Could not open: ${failed.joinToString()}."))
    }
}
