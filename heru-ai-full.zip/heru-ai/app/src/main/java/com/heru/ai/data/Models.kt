package com.heru.ai.data

enum class SettingsPage(val label: String) {
    MAIN("Settings"), WIFI("Wi-Fi"), BLUETOOTH("Bluetooth"), DISPLAY("Display"), SOUND("Sound"),
    BATTERY("Battery saver"), LOCATION("Location"), APPS("Apps"), AIRPLANE("Airplane mode"),
    ACCESSIBILITY("Accessibility"), APP_DETAILS("HERU app info")
}

enum class GestureKind(val label: String) {
    BACK("Back"), HOME("Home"), RECENTS("Recent apps"), SCROLL_DOWN("Scroll down"),
    SCROLL_UP("Scroll up"), SWIPE_LEFT("Swipe left"), SWIPE_RIGHT("Swipe right"), TAP("Tap")
}

data class AppRef(val pkg: String, val label: String)

sealed interface HeruAction {
    data class OpenApp(val app: AppRef) : HeruAction
    data class OpenSettingsPage(val page: SettingsPage) : HeruAction
    data class YouTube(val query: String? = null, val url: String? = null, val music: Boolean = false) : HeruAction
    data class Gesture(val kind: GestureKind, val x: Float = 0f, val y: Float = 0f) : HeruAction
    data class RunRoutine(val name: String, val apps: List<AppRef>) : HeruAction
    data object OpenCamera : HeruAction
    data class Navigate(val route: String) : HeruAction
}

data class ActionChoice(val label: String, val action: HeruAction?)

data class ChatMessage(
    val id: Long,
    val text: String,
    val fromUser: Boolean,
    val isNote: Boolean = false,
    val choices: List<ActionChoice> = emptyList(),
    val streaming: Boolean = false
)

data class MemoryItem(val id: Long, val text: String)
data class Snippet(val id: Long, val title: String, val language: String, val code: String)
data class LogEntry(val time: Long, val text: String, val ok: Boolean)
data class Routine(val id: Long, val name: String, val apps: List<AppRef>)

/** Pick Hinglish/Hindi text or English text depending on the language setting. */
fun L(lang: HeruLanguage, hinglish: String, english: String): String =
    if (lang == HeruLanguage.ENGLISH) english else hinglish
