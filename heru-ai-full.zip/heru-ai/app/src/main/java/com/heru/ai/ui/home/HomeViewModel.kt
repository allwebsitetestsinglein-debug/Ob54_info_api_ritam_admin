package com.heru.ai.ui.home

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.heru.ai.HeruApplication
import com.heru.ai.actions.Routed
import com.heru.ai.ai.GeminiException
import com.heru.ai.ai.Persona
import com.heru.ai.ai.Turn
import com.heru.ai.data.ActionChoice
import com.heru.ai.data.ChatMessage
import com.heru.ai.data.HeruAction
import com.heru.ai.data.HeruSettings
import com.heru.ai.data.L
import com.heru.ai.data.SettingsPage
import com.heru.ai.voice.VoiceController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class HeruState(val label: String) {
    IDLE("Ready"),
    LISTENING("Listening…"),
    THINKING("Thinking…"),
    SPEAKING("Speaking…"),
    EXECUTING("Executing…")
}

class HomeViewModel(app: Application) : AndroidViewModel(app), VoiceController.Callback {
    private val h = app as HeruApplication
    private val keyPattern = Regex("AIza[0-9A-Za-z_\\-]{30,}")
    private var nextId = System.currentTimeMillis()
    private fun newId() = nextId++

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = _messages.asStateFlow()
    private val _state = MutableStateFlow(HeruState.IDLE)
    val state = _state.asStateFlow()
    private val _partial = MutableStateFlow("")
    val partial = _partial.asStateFlow()
    private val _nav = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val navEvents = _nav.asSharedFlow()
    private var job: Job? = null

    private suspend fun settings(): HeruSettings = h.settingsRepo.settings.first()

    private fun greeting() = ChatMessage(
        newId(),
        "Yo bhai! HERU yahan. Bol, aaj kya karna hai? (Chat ke liye Settings > AI me Gemini API key daal.)",
        false
    )

    init {
        h.voice.callback = this
        viewModelScope.launch {
            val s = settings()
            val saved = if (s.saveHistory) withContext(Dispatchers.IO) { h.store.loadChat() } else emptyList()
            nextId = maxOf(nextId, (saved.maxOfOrNull { it.id } ?: 0L) + 1)
            _messages.value = if (saved.isEmpty()) listOf(greeting()) else saved
        }
        viewModelScope.launch { h.chatCleared.collect { _messages.value = listOf(greeting()) } }
    }

    // ---------- voice callbacks ----------
    override fun onListening(active: Boolean) {
        if (active) _state.value = HeruState.LISTENING
        else if (_state.value == HeruState.LISTENING) _state.value = HeruState.IDLE
    }

    override fun onPartial(text: String) { _partial.value = text }

    override fun onFinal(text: String) {
        _partial.value = ""
        send(text)
    }

    override fun onSpeaking(active: Boolean) {
        if (active) _state.value = HeruState.SPEAKING
        else if (_state.value == HeruState.SPEAKING) _state.value = HeruState.IDLE
    }

    override fun onError(msg: String) {
        _partial.value = ""
        if (_state.value == HeruState.LISTENING) _state.value = HeruState.IDLE
        note(msg)
    }

    // ---------- UI entry points ----------
    fun toggleListening() {
        if (_state.value == HeruState.LISTENING) {
            h.voice.stopListening()
            return
        }
        viewModelScope.launch { h.voice.startListening(settings().language.sttTag) }
    }

    fun onMicPermissionDenied() {
        note(
            "Microphone permission nahi mili, isliye voice input band hai. Text se baat kar sakta hai, ya permission de de.",
            listOf(ActionChoice("App settings kholo", HeruAction.OpenSettingsPage(SettingsPage.APP_DETAILS)))
        )
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (keyPattern.containsMatchIn(t)) {
            note("Ye message Gemini API key jaisa lag raha hai, isliye bheja ya save nahi kiya. Key sirf Settings > AI me daalna.")
            return
        }
        job?.cancel()
        append(ChatMessage(newId(), t, true))
        job = viewModelScope.launch { handle(t) }
    }

    fun onChoice(messageId: Long, choice: ActionChoice) {
        updateMessage(messageId) { it.copy(choices = emptyList()) }
        viewModelScope.launch {
            val s = settings()
            val a = choice.action
            if (a == null) note(L(s.language, "Theek hai, cancel kar diya.", "Okay, cancelled.")) else perform(a, s)
        }
    }

    fun runDirect(action: HeruAction) {
        viewModelScope.launch { perform(action, settings()) }
    }

    fun stopAll() {
        job?.cancel()
        h.voice.stopSpeaking()
        h.voice.cancelListening()
        _partial.value = ""
        _state.value = HeruState.IDLE
        _messages.update { l -> l.map { if (it.streaming) it.copy(streaming = false) else it } }
    }

    override fun onCleared() {
        if (h.voice.callback === this) h.voice.callback = null
        super.onCleared()
    }

    // ---------- core flow ----------
    private suspend fun handle(text: String) {
        val s = settings()
        _state.value = HeruState.THINKING
        try {
            val routed = try {
                h.router.route(text, s.language)
            } catch (e: Exception) {
                Routed.NotCommand
            }
            when (routed) {
                is Routed.Remember -> {
                    withContext(Dispatchers.IO) { h.store.addMemory(routed.text) }
                    reply(
                        L(
                            s.language,
                            "Done bhai, yaad rakh liya: \"${routed.text}\". Settings > Memory me dekh ya delete kar sakta hai.",
                            "Done, I'll remember: \"${routed.text}\". You can review or delete it in Settings > Memory."
                        ),
                        s
                    )
                }
                is Routed.Say -> reply(routed.text, s)
                is Routed.Ambiguous -> append(
                    ChatMessage(
                        newId(), routed.say, false,
                        choices = routed.options.map { ActionChoice(it.label, HeruAction.OpenApp(it)) } +
                            ActionChoice("Cancel", null)
                    )
                )
                is Routed.Act -> {
                    if (s.confirmActions) {
                        append(
                            ChatMessage(
                                newId(), h.executor.describe(routed.action, s.language), false,
                                choices = listOf(
                                    ActionChoice(L(s.language, "Haan", "Yes"), routed.action),
                                    ActionChoice(L(s.language, "Nahi", "No"), null)
                                )
                            )
                        )
                    } else {
                        perform(routed.action, s)
                    }
                }
                Routed.NotCommand -> chat(s)
            }
        } finally {
            if (_state.value == HeruState.THINKING || _state.value == HeruState.EXECUTING) _state.value = HeruState.IDLE
            persist(s)
        }
    }

    private fun perform(a: HeruAction, s: HeruSettings) {
        if (a is HeruAction.Navigate) {
            _nav.tryEmit(a.route)
            return
        }
        _state.value = HeruState.EXECUTING
        val r = h.runAction(a, s.language)
        append(ChatMessage(newId(), r.message, false, isNote = !r.ok))
        _state.value = HeruState.IDLE
        persist(s)
        if (r.ok) speakIf(s, r.message)
    }

    private fun reply(text: String, s: HeruSettings) {
        append(ChatMessage(newId(), text, false))
        speakIf(s, text)
    }

    private suspend fun chat(s: HeruSettings) {
        val key = withContext(Dispatchers.IO) { h.keyStore.load() }
        if (key.isNullOrBlank()) {
            append(
                ChatMessage(
                    newId(),
                    L(
                        s.language,
                        "Gemini API key set nahi hai, isliye main chat ka jawab nahi de sakta. Settings > AI me key daal. (Apps kholna, YouTube search jaise commands bina key ke chalte hain.)",
                        "No Gemini API key is set, so I can't answer chat messages. Add one in Settings > AI. (Commands like opening apps or YouTube search work without a key.)"
                    ),
                    false, isNote = true,
                    choices = listOf(ActionChoice("Settings kholo", HeruAction.Navigate("settings")))
                )
            )
            return
        }
        val memories = withContext(Dispatchers.IO) { h.store.loadMemories() }
        val system = Persona.systemPrompt(s, memories)
        val turns = buildTurns()
        val replyId = newId()
        append(ChatMessage(replyId, "", false, streaming = true))
        val sb = StringBuilder()
        try {
            h.gemini.stream(key, s.model, system, turns, s.temperature, s.maxTokens).collect { chunk ->
                sb.append(chunk)
                updateMessage(replyId) { it.copy(text = sb.toString()) }
            }
            if (sb.isBlank()) {
                throw GeminiException("Gemini ne khaali jawab diya (safety filter ya max token chhota ho sakta hai).")
            }
            updateMessage(replyId) { it.copy(streaming = false) }
            speakIf(s, sb.toString())
        } catch (e: CancellationException) {
            updateMessage(replyId) { it.copy(streaming = false) }
            throw e
        } catch (e: GeminiException) {
            failReply(replyId, sb, e.message ?: "Gemini error.")
        } catch (e: Exception) {
            Log.w("HERU", "chat failed: ${e.javaClass.simpleName}")
            failReply(replyId, sb, "Kuch gadbad ho gayi (${e.javaClass.simpleName}).")
        }
    }

    private fun failReply(replyId: Long, partialText: StringBuilder, msg: String) {
        if (partialText.isBlank()) {
            _messages.update { l -> l.filter { it.id != replyId } }
        } else {
            updateMessage(replyId) { it.copy(streaming = false) }
        }
        note(msg)
    }

    private fun buildTurns(): List<Turn> {
        val recent = _messages.value.filter { !it.isNote && !it.streaming && it.text.isNotBlank() }.takeLast(20)
        val turns = ArrayList<Turn>()
        for (m in recent) {
            val role = if (m.fromUser) "user" else "model"
            if (turns.isNotEmpty() && turns.last().role == role) {
                turns[turns.lastIndex] = Turn(role, turns.last().text + "\n" + m.text)
            } else {
                turns.add(Turn(role, m.text))
            }
        }
        while (turns.isNotEmpty() && turns.first().role != "user") turns.removeAt(0)
        while (turns.isNotEmpty() && turns.last().role != "user") turns.removeAt(turns.lastIndex)
        return turns
    }

    // ---------- helpers ----------
    private fun append(m: ChatMessage) { _messages.update { it + m } }

    private fun note(text: String, choices: List<ActionChoice> = emptyList()) {
        append(ChatMessage(newId(), text, false, isNote = true, choices = choices))
    }

    private fun updateMessage(id: Long, f: (ChatMessage) -> ChatMessage) {
        _messages.update { l -> l.map { if (it.id == id) f(it) else it } }
    }

    private fun speakIf(s: HeruSettings, text: String) {
        if (s.voiceReplies) h.voice.speak(text, s.language.ttsTag, s.ttsRate, s.ttsPitch, s.ttsVoice)
    }

    private fun persist(s: HeruSettings) {
        if (!s.saveHistory) return
        val snapshot = _messages.value.filter { !it.streaming }
        h.appScope.launch { h.store.saveChat(snapshot) }
    }
}
