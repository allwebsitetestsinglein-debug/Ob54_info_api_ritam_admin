package com.heru.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(message: String) : Exception(message)

data class Turn(val role: String, val text: String) // role: "user" or "model"

/**
 * Minimal client for the Gemini REST API (generativelanguage.googleapis.com, v1beta).
 * The API key is sent in the x-goog-api-key header, never in the URL, and is never logged.
 */
class GeminiClient {
    private val base = "https://generativelanguage.googleapis.com/v1beta"

    private fun open(url: String, apiKey: String, method: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        c.setRequestProperty("x-goog-api-key", apiKey)
        c.setRequestProperty("Content-Type", "application/json")
        return c
    }

    private fun checkModel(model: String) {
        if (!model.matches(Regex("[A-Za-z0-9._\\-]+"))) throw GeminiException("Model ka naam galat hai.")
    }

    suspend fun listModels(apiKey: String): List<String> = withContext(Dispatchers.IO) {
        val c = open("$base/models?pageSize=200", apiKey, "GET")
        try {
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw GeminiException(friendly(code, text))
            val arr = JSONObject(text).optJSONArray("models") ?: JSONArray()
            val out = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                var ok = false
                for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") ok = true
                val name = m.optString("name").removePrefix("models/")
                if (ok && name.startsWith("gemini")) out.add(name)
            }
            out.sorted()
        } catch (e: IOException) {
            throw netError(e)
        } finally {
            c.disconnect()
        }
    }

    suspend fun generate(
        apiKey: String, model: String, system: String, turns: List<Turn>,
        temperature: Float, maxTokens: Int
    ): String = withContext(Dispatchers.IO) {
        checkModel(model)
        val c = open("$base/models/$model:generateContent", apiKey, "POST")
        try {
            c.doOutput = true
            c.outputStream.use { it.write(body(system, turns, temperature, maxTokens).toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw GeminiException(friendly(code, text))
            extractText(JSONObject(text))
        } catch (e: IOException) {
            throw netError(e)
        } finally {
            c.disconnect()
        }
    }

    /** Streams text chunks using Server-Sent Events (alt=sse). */
    fun stream(
        apiKey: String, model: String, system: String, turns: List<Turn>,
        temperature: Float, maxTokens: Int
    ): Flow<String> = flow {
        checkModel(model)
        val c = open("$base/models/$model:streamGenerateContent?alt=sse", apiKey, "POST")
        try {
            c.doOutput = true
            c.outputStream.use { it.write(body(system, turns, temperature, maxTokens).toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) {
                val err = c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                throw GeminiException(friendly(code, err))
            }
            c.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.removePrefix("data:").trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue
                    val chunk = try {
                        extractText(JSONObject(payload))
                    } catch (e: JSONException) {
                        ""
                    }
                    if (chunk.isNotEmpty()) emit(chunk)
                }
            }
        } catch (e: IOException) {
            throw netError(e)
        } finally {
            c.disconnect()
        }
    }.flowOn(Dispatchers.IO)

    private fun body(system: String, turns: List<Turn>, temperature: Float, maxTokens: Int): String {
        val contents = JSONArray()
        turns.forEach {
            contents.put(
                JSONObject().put("role", it.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }
        val o = JSONObject().put("contents", contents)
        if (system.isNotBlank()) {
            o.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        }
        o.put(
            "generationConfig",
            JSONObject().put("temperature", temperature.toDouble()).put("maxOutputTokens", maxTokens)
        )
        return o.toString()
    }

    private fun extractText(j: JSONObject): String {
        val cands = j.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = j.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            if (reason.isNotEmpty()) throw GeminiException("Gemini ne ye request block kar di ($reason).")
            return ""
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        return sb.toString()
    }

    private fun friendly(code: Int, body: String): String {
        val detail = try {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: Exception) {
            ""
        }
        val head = when (code) {
            400 -> "Request ya API key galat lag rahi hai (400)"
            401, 403 -> "API key valid nahi hai ya is model ka access nahi (HTTP $code)"
            404 -> "Model nahi mila (404) - Settings me model ka naam check kar"
            429 -> "Rate limit ya quota khatam (429) - thodi der baad try kar"
            in 500..599 -> "Gemini server problem ($code) - baad me try kar"
            else -> "Error (HTTP $code)"
        }
        return if (detail.isNotBlank()) "$head: ${detail.take(180)}" else head
    }

    private fun netError(e: IOException): GeminiException =
        GeminiException("Network problem: internet connection check kar. (${e.javaClass.simpleName})")
}
