package com.heru.ai.actions

import com.heru.ai.data.AppRef
import com.heru.ai.data.AppRepository
import com.heru.ai.data.GestureKind
import com.heru.ai.data.HeruAction
import com.heru.ai.data.HeruLanguage
import com.heru.ai.data.L
import com.heru.ai.data.LocalStore
import com.heru.ai.data.SettingsPage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

sealed interface Routed {
    data class Act(val action: HeruAction, val say: String) : Routed
    data class Ambiguous(val say: String, val options: List<AppRef>) : Routed
    data class Say(val text: String) : Routed
    data class Remember(val text: String) : Routed
    data object NotCommand : Routed
}

/**
 * Rule-based Hinglish/English command parser. It runs locally (works offline) BEFORE a message is sent to Gemini.
 * Anything it doesn't recognise returns NotCommand and goes to the AI chat.
 */
class CommandRouter(private val apps: AppRepository, private val store: LocalStore) {

    private val fillers = setOf(
        "heru", "hey", "ok", "okay", "bhai", "yaar", "bro", "please", "plz", "pls", "zara", "jara", "ek", "na",
        "app", "application", "ko", "ka", "ki", "ke", "kar", "karo", "kardo", "de", "do", "dena", "dijiye",
        "mujhe", "meri", "mera", "the", "a", "to", "me", "mein", "par", "pe", "on", "in", "se", "from",
        "jaldi", "abhi", "now"
    )
    private val openVerbs = setOf("kholo", "khol", "kholna", "open", "launch", "start", "chalu", "shuru")
    private val hindiOpen = setOf("kholo", "khol", "kholna")
    private val playVerbs = setOf(
        "chala", "chalao", "chalado", "play", "bajao", "baja", "sunao", "suna", "search", "dhundh", "dhundho",
        "dhoondh", "dikhao", "lagao", "laga", "run"
    )
    private val musicWords = setOf("gana", "gaana", "song", "songs", "music", "lofi", "lo-fi", "bhajan", "track")
    private val aliases = mapOf(
        "insta" to "instagram", "yt" to "youtube", "fb" to "facebook", "gpay" to "google pay",
        "whatsap" to "whatsapp", "watsapp" to "whatsapp", "msg" to "messages"
    )

    private val gestureMap: Map<String, GestureKind> = mapOf(
        "back" to GestureKind.BACK, "back jao" to GestureKind.BACK, "go back" to GestureKind.BACK,
        "peeche jao" to GestureKind.BACK, "wapas jao" to GestureKind.BACK, "back dabao" to GestureKind.BACK,
        "home" to GestureKind.HOME, "home jao" to GestureKind.HOME, "go home" to GestureKind.HOME,
        "home screen" to GestureKind.HOME, "home dabao" to GestureKind.HOME,
        "recent apps" to GestureKind.RECENTS, "recents" to GestureKind.RECENTS, "recent" to GestureKind.RECENTS,
        "scroll down" to GestureKind.SCROLL_DOWN, "neeche scroll" to GestureKind.SCROLL_DOWN,
        "niche scroll" to GestureKind.SCROLL_DOWN, "scroll neeche" to GestureKind.SCROLL_DOWN,
        "scroll up" to GestureKind.SCROLL_UP, "upar scroll" to GestureKind.SCROLL_UP,
        "scroll upar" to GestureKind.SCROLL_UP,
        "swipe left" to GestureKind.SWIPE_LEFT, "left swipe" to GestureKind.SWIPE_LEFT,
        "swipe right" to GestureKind.SWIPE_RIGHT, "right swipe" to GestureKind.SWIPE_RIGHT
    )

    private val settingsKeywords: List<Pair<List<String>, SettingsPage>> = listOf(
        listOf("wifi", "wi-fi", "wi fi") to SettingsPage.WIFI,
        listOf("bluetooth") to SettingsPage.BLUETOOTH,
        listOf("display", "brightness") to SettingsPage.DISPLAY,
        listOf("sound", "volume") to SettingsPage.SOUND,
        listOf("battery") to SettingsPage.BATTERY,
        listOf("location", "gps") to SettingsPage.LOCATION,
        listOf("airplane", "flight mode") to SettingsPage.AIRPLANE,
        listOf("accessibility") to SettingsPage.ACCESSIBILITY
    )

    suspend fun route(raw: String, lang: HeruLanguage): Routed {
        val base = raw.trim()
        if (base.isEmpty()) return Routed.NotCommand
        val clean = base.lowercase(Locale.ROOT)
            .replace(Regex("[,!?\u0964.\"]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val tokens = clean.split(" ").filter { it.isNotEmpty() }
        val core = tokens.filter { it !in fillers }
        val coreStr = core.joinToString(" ")
        val hasOpen = tokens.any { it in openVerbs }
        val hasPlay = tokens.any { it in playVerbs }

        // 1. "yaad rakh ..." / "remember ..."
        Regex(
            "^(?:(?:hey |ok )?heru[ ,]+)?(?:yaad rakh(?:o|na)?|remember(?: that)?)\\s*[:,-]?\\s*(.+)\$",
            RegexOption.IGNORE_CASE
        ).find(base)?.let { return Routed.Remember(it.groupValues[1].trim()) }

        // 2. explicit YouTube link
        Regex("https?://\\S*(?:youtube\\.com|youtu\\.be)\\S*", RegexOption.IGNORE_CASE).find(base)?.let {
            if (hasOpen || hasPlay) {
                return Routed.Act(
                    HeruAction.YouTube(url = it.value),
                    L(lang, "Bilkul bhai, ye YouTube link khol raha hoon.", "Sure, opening that YouTube link.")
                )
            }
        }

        // 3. gestures (need the Accessibility service)
        gestureMap[coreStr]?.let {
            return Routed.Act(
                HeruAction.Gesture(it),
                L(lang, "Theek hai, '${it.label}' gesture bhejta hoon.", "Okay, sending the '${it.label}' gesture.")
            )
        }

        // 4. routines
        if (tokens.contains("routine") && (hasOpen || hasPlay)) {
            val routines = withContext(Dispatchers.IO) { store.loadRoutines() }
            val r = routines.firstOrNull { clean.contains(it.name.lowercase(Locale.ROOT)) }
            return if (r != null) {
                Routed.Act(
                    HeruAction.RunRoutine(r.name, r.apps),
                    L(lang, "Routine '${r.name}' chala raha hoon.", "Running routine '${r.name}'.")
                )
            } else {
                Routed.Say(L(lang, "Is naam ka routine nahi mila. Automation screen me bana le.", "No routine with that name. Create one in the Automation screen."))
            }
        }

        // 5. YouTube / music search
        val mentionsYT = tokens.any { it == "youtube" || it == "yt" || it == "ytmusic" }
        val isMusicApp = clean.contains("youtube music") || tokens.contains("ytmusic")
        val musicish = tokens.any { it in musicWords }
        if ((mentionsYT && (hasOpen || hasPlay)) || (musicish && hasPlay)) {
            val drop = fillers + playVerbs + openVerbs + setOf("youtube", "yt", "ytmusic")
            val query = tokens
                .filter { it !in drop }
                .filter { !(isMusicApp && it == "music") }
                .map { if (it == "gana" || it == "gaana") "songs" else it }
                .joinToString(" ")
                .trim()
            return if (query.isBlank()) {
                Routed.Act(
                    HeruAction.YouTube(music = isMusicApp),
                    L(lang, "Bilkul bhai, YouTube khol raha hoon.", "Sure, opening YouTube.")
                )
            } else {
                Routed.Act(
                    HeruAction.YouTube(query = query, music = isMusicApp),
                    L(
                        lang,
                        "Bilkul bhai, YouTube pe '$query' ka search khol raha hoon. Play tu khud kar lena.",
                        "Sure, opening a YouTube search for '$query'. You'll press play."
                    )
                )
            }
        }

        // 6. camera app
        if (tokens.contains("camera") && hasOpen && tokens.size <= 4) {
            return Routed.Act(HeruAction.OpenCamera, L(lang, "Camera khol raha hoon.", "Opening the camera."))
        }

        // 7. system settings pages
        val toggleWords = setOf("on", "off", "band", "chalu")
        if (hasOpen || tokens.any { it in toggleWords } || coreStr == "settings" || coreStr == "setting") {
            var page: SettingsPage? = null
            for ((words, p) in settingsKeywords) {
                if (words.any { clean.contains(it) }) { page = p; break }
            }
            if (page == null && tokens.any { it == "settings" || it == "setting" }) page = SettingsPage.MAIN
            if (page != null) {
                return Routed.Act(
                    HeruAction.OpenSettingsPage(page),
                    L(lang, "Theek hai, ${page.label} khol raha hoon.", "Okay, opening ${page.label}.")
                )
            }
        }

        // 8. open an installed app
        if (hasOpen && tokens.size <= 6) {
            val name = tokens.filter { it !in fillers && it !in openVerbs }.joinToString(" ")
            val hindi = tokens.any { it in hindiOpen }
            if (name.isBlank()) {
                return if (hindi) Routed.Say(L(lang, "Kaunsa app kholu bhai?", "Which app should I open?")) else Routed.NotCommand
            }
            val found = match(name, apps.apps())
            return when {
                found.size == 1 -> Routed.Act(
                    HeruAction.OpenApp(found[0]),
                    L(lang, "Bilkul bhai, ${found[0].label} khol raha hoon.", "Sure, opening ${found[0].label}.")
                )
                found.size > 1 -> Routed.Ambiguous(
                    L(lang, "Kaunsa wala kholu bhai?", "Which one should I open?"),
                    found
                )
                hindi -> Routed.Say(
                    L(lang, "'$name' naam ka app nahi mila. Apps screen me check kar le.", "I couldn't find an app called '$name'. Check the Apps screen.")
                )
                else -> Routed.NotCommand
            }
        }

        return Routed.NotCommand
    }

    private fun norm(s: String) = s.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    private fun match(name: String, installed: List<AppRef>): List<AppRef> {
        val q = norm(aliases[name] ?: name)
        if (q.isEmpty()) return emptyList()
        val exact = installed.filter { norm(it.label) == q }
        if (exact.isNotEmpty()) return exact.take(5)
        val starts = installed.filter { norm(it.label).startsWith(q) }
        if (starts.isNotEmpty()) return starts.take(5)
        return installed.filter { norm(it.label).contains(q) }.take(5)
    }
}
