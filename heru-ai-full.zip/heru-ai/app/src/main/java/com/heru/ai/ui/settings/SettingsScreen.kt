package com.heru.ai.ui.settings

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.heru.ai.actions.HeruAccessibilityService
import com.heru.ai.data.HeruLanguage
import com.heru.ai.data.HeruSettings
import com.heru.ai.data.Keys
import com.heru.ai.data.Personality
import com.heru.ai.data.ResponseStyle
import com.heru.ai.ui.Routes
import com.heru.ai.ui.SettingsViewModel
import com.heru.ai.ui.components.Caption
import com.heru.ai.ui.components.ChoiceRow
import com.heru.ai.ui.components.HeruButton
import com.heru.ai.ui.components.Panel
import com.heru.ai.ui.components.ScrollScreen
import com.heru.ai.ui.components.SectionTitle
import com.heru.ai.ui.components.SwitchRow

@Composable
fun SettingsScreen(
    settings: HeruSettings,
    vm: SettingsViewModel,
    onBack: () -> Unit,
    onOpen: (String) -> Unit
) {
    val ctx = LocalContext.current
    val hasKey by vm.hasKey.collectAsStateWithLifecycle()
    val test by vm.testResult.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val models by vm.models.collectAsStateWithLifecycle()
    val voices by vm.voices.collectAsStateWithLifecycle()

    var keyInput by remember { mutableStateOf("") }
    var modelInput by remember(settings.model) { mutableStateOf(settings.model) }
    var extra by remember(settings.customPrompt) { mutableStateOf(settings.customPrompt) }
    var temp by remember(settings.temperature) { mutableFloatStateOf(settings.temperature) }
    var tokens by remember(settings.maxTokens) { mutableFloatStateOf(settings.maxTokens.toFloat()) }
    var rate by remember(settings.ttsRate) { mutableFloatStateOf(settings.ttsRate) }
    var pitch by remember(settings.ttsPitch) { mutableFloatStateOf(settings.ttsPitch) }

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val micGranted = remember(tick) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }
    val a11yOn = remember(tick) { HeruAccessibilityService.instance != null }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    var confirmClear by remember { mutableStateOf(false) }

    ScrollScreen("Settings", onBack) {

        // ---------------- AI ----------------
        SectionTitle("AI (Gemini)")
        Panel {
            Caption(if (hasKey) "API key saved (Android Keystore se encrypted)." else "Abhi koi API key saved nahi hai.")
            OutlinedTextField(
                value = keyInput,
                onValueChange = { keyInput = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Gemini API key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeruButton("Save", { vm.saveKey(keyInput); keyInput = "" }, enabled = keyInput.isNotBlank())
                HeruButton("Test", { vm.testConnection(keyInput) }, enabled = !busy, filled = false)
                if (hasKey) HeruButton("Remove", { vm.removeKey() }, filled = false)
            }
            test?.let {
                Text(
                    it.text,
                    color = if (it.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
            }
            Caption(
                "Security: key on-device Keystore me encrypted rehti hai, lekin rooted ya compromised phone pe poori tarah safe nahi hai. " +
                    "Production me apna backend proxy use kar."
            )
        }

        Panel {
            Caption("Model")
            OutlinedTextField(
                value = modelInput,
                onValueChange = { modelInput = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Model name (jaise gemini-2.5-flash)") }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeruButton("Set model", { vm.put(Keys.MODEL, modelInput.trim()) }, enabled = modelInput.isNotBlank())
                HeruButton("Models laao", { vm.fetchModels(keyInput) }, enabled = !busy, filled = false)
            }
            if (models.isNotEmpty()) {
                Caption("Apne key ke liye available models:")
                ChoiceRow(models, models.indexOf(settings.model)) { vm.put(Keys.MODEL, models[it]) }
            }
            Caption("Current: ${settings.model}")
        }

        Panel {
            Caption("Creativity (temperature): ${"%.1f".format(temp)}")
            Slider(
                value = temp,
                onValueChange = { temp = it },
                onValueChangeFinished = { vm.put(Keys.TEMPERATURE, temp) },
                valueRange = 0f..2f
            )
            Caption("Max response tokens: ${tokens.toInt()}")
            Slider(
                value = tokens,
                onValueChange = { tokens = it },
                onValueChangeFinished = { vm.put(Keys.MAX_TOKENS, tokens.toInt()) },
                valueRange = 256f..4096f,
                steps = 14
            )
            Caption("Kuch Gemini models soch-vichar (thinking) me bhi tokens kharch karte hain, to jawab chhota ho to ye badha.")
        }

        Caption("Personality")
        ChoiceRow(Personality.values().map { it.label }, settings.personality.ordinal) {
            vm.put(Keys.PERSONALITY, Personality.values()[it].name)
        }
        Caption("Response style")
        ChoiceRow(ResponseStyle.values().map { it.label }, settings.style.ordinal) {
            vm.put(Keys.STYLE, ResponseStyle.values()[it].name)
        }
        Panel {
            OutlinedTextField(
                value = extra,
                onValueChange = { extra = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                label = { Text("Extra instructions for HERU (optional)") }
            )
            HeruButton("Save instructions", { vm.put(Keys.CUSTOM, extra.trim()) })
            Caption("Ye HERU ke base prompt ke saath Gemini ko jaate hain. Honesty rules override nahi hote.")
        }

        // ---------------- Voice ----------------
        SectionTitle("Voice")
        Caption("Speech language")
        ChoiceRow(HeruLanguage.values().map { it.label }, settings.language.ordinal) {
            vm.put(Keys.LANGUAGE, HeruLanguage.values()[it].name)
        }
        SwitchRow("Spoken replies", "HERU jawab bolke bhi sunayega.", settings.voiceReplies) { vm.put(Keys.VOICE, it) }
        Panel {
            Caption("Speech rate: ${"%.1f".format(rate)}")
            Slider(rate, { rate = it }, onValueChangeFinished = { vm.put(Keys.RATE, rate) }, valueRange = 0.5f..2f)
            Caption("Pitch: ${"%.1f".format(pitch)}")
            Slider(pitch, { pitch = it }, onValueChangeFinished = { vm.put(Keys.PITCH, pitch) }, valueRange = 0.5f..2f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeruButton("Voices laao", { vm.loadVoices() }, filled = false)
                HeruButton("Voice test", { vm.testVoice() })
            }
            if (voices.isNotEmpty()) {
                val names = listOf("Default") + voices.take(12)
                val sel = if (settings.ttsVoice.isBlank()) 0 else names.indexOf(settings.ttsVoice).coerceAtLeast(0)
                ChoiceRow(names, sel) { vm.put(Keys.VOICE_NAME, if (it == 0) "" else names[it]) }
            }
            Caption("Hindi voice na mile to phone ki Text-to-speech settings me voice data download kar.")
        }

        // ---------------- Permissions ----------------
        SectionTitle("Permissions")
        Panel {
            Caption("Microphone: ${if (micGranted) "allowed" else "not allowed"}")
            if (!micGranted) HeruButton("Allow microphone", { micLauncher.launch(Manifest.permission.RECORD_AUDIO) })
        }
        Panel {
            Caption("Accessibility service: ${if (a11yOn) "ON" else "off"}")
            HeruButton("Automation screen kholo", { onOpen(Routes.AUTOMATION) }, filled = false)
        }
        Caption("Notification access, camera preview aur file access abhi implement nahi hain, isliye unki permission app maangta hi nahi.")

        // ---------------- Appearance ----------------
        SectionTitle("Appearance")
        SwitchRow("Dark mode", "Neon look dark me sabse accha lagta hai.", settings.darkMode) { vm.put(Keys.DARK, it) }
        Caption("Accent colour")
        val accents = listOf("cyan", "blue", "violet")
        ChoiceRow(accents.map { it.replaceFirstChar(Char::uppercase) }, accents.indexOf(settings.accent).coerceAtLeast(0)) {
            vm.put(Keys.ACCENT, accents[it])
        }
        Caption("Animation intensity (kam = battery bachat)")
        ChoiceRow(listOf("Off", "Normal", "Rich"), settings.animationLevel) { vm.put(Keys.ANIM, it) }
        SwitchRow("Compact layout", "Home screen pe kam spacing.", settings.compactLayout) { vm.put(Keys.COMPACT, it) }

        // ---------------- Privacy ----------------
        SectionTitle("Privacy")
        SwitchRow(
            "Save chat history",
            "Off karne pe saved history delete ho jati hai.",
            settings.saveHistory
        ) { vm.setSaveHistory(it) }
        Panel {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeruButton("Memory dekho", { onOpen(Routes.MEMORY) }, filled = false)
                HeruButton(if (confirmClear) "Pakka? Tap again" else "Clear chat", {
                    if (confirmClear) { vm.clearChat(); confirmClear = false } else confirmClear = true
                }, filled = false)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeruButton("Clear memories", { vm.clearMemories() }, filled = false)
                HeruButton("Reset settings", { vm.resetSettings() }, filled = false)
            }
        }
        Panel {
            Caption("Gemini ko kya jaata hai:")
            Caption("• Tera message, pichhle ~20 messages ka context, HERU ke jawab, aur jo memories tune save ki hain.")
            Caption("• Coding mode me jo code/text tu bhejta hai.")
            Caption("• API key sirf authentication header me jaati hai, chat me nahi.")
            Caption("Ye sab Google ke servers pe jaata hai aur Gemini API ki terms/privacy policy lagu hoti hai. Apps ki list, contacts, files aur screen content kabhi nahi bheje jaate.")
        }

        // ---------------- Automation ----------------
        SectionTitle("Automation")
        SwitchRow(
            "Confirm before actions",
            "HERU apps kholne ya gesture bhejne se pehle poochega.",
            settings.confirmActions
        ) { vm.put(Keys.CONFIRM, it) }
        Panel {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeruButton("Automation & routines", { onOpen(Routes.AUTOMATION) }, filled = false)
                HeruButton("Action history", { onOpen(Routes.ACTION_LOG) }, filled = false)
            }
        }
    }
}
